/**
 * Google 雲端硬碟上傳（零依賴，只用 Node 內建模組）
 * ============================================================
 * 取代原本的 pCloud。憑證只存在中樞這一台，不會下發給任何 iPad。
 *
 * 授權方式：OAuth 2.0 refresh token
 * ------------------------------------------------------------
 * Google 的 access token 只有一小時，所以我們存的是「refresh token」，
 * 每次上傳前用它換一張新的短效 token。refresh token 不會過期
 * （除非你自己到 Google 帳號設定撤銷），所以只要授權一次就好。
 *
 * 拿 refresh token 有兩條路，兩條都支援：
 *   A. 在中樞這台機器的瀏覽器打開 http://localhost:8080/api/gdrive/auth
 *      → 走完 Google 同意畫面 → 中樞自動收下 token（推薦，最不會出錯）
 *   B. 用 Google OAuth Playground 自己換一組，貼進設定頁
 *
 * 為什麼不用「服務帳號」？
 *   服務帳號在個人 Google 雲端硬碟沒有儲存空間配額，檔案傳上去
 *   會算在服務帳號自己頭上而且你在自己的雲端硬碟裡看不到，
 *   對攤商來說完全不直覺。用自己的帳號授權才會出現在「我的雲端硬碟」。
 */

const https = require('https')

const SCOPE = 'https://www.googleapis.com/auth/drive.file'
const FOLDER_MIME = 'application/vnd.google-apps.folder'

// ---------------------------------------------------------------- HTTP 小工具

function request(options, body) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, res => {
      const chunks = []
      res.on('data', c => chunks.push(c))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        let json = null
        try { json = JSON.parse(text) } catch { /* 不是 JSON 就算了 */ }
        if (res.statusCode >= 200 && res.statusCode < 300) return resolve(json ?? text)
        const msg = json?.error?.message || json?.error_description || json?.error || text.slice(0, 300)
        // 「has not been used ... or it is disabled」是最常見的第一次設定卡點：
        // OAuth 憑證申請好了，但忘記在同一個 GCP 專案裡把 Drive API 打開。
        // 直接把中文提示放進錯誤訊息，不用另外去查文件。
        const hint = /has not been used|it is disabled/i.test(String(msg))
          ? '（這通常代表你在 Google Cloud Console 建立憑證後，忘記啟用 Google Drive API —— 到 Cloud Console →「已啟用的 API」→ 搜尋 Drive → 按啟用，等 1～2 分鐘再重新授權一次）'
          : ''
        reject(new Error(`Google 回應 ${res.statusCode}：${msg}${hint}`))
      })
    })
    req.on('error', reject)
    req.setTimeout(30000, () => { req.destroy(new Error('連線 Google 逾時')) })
    if (body) req.write(body)
    req.end()
  })
}

function form(obj) {
  return Object.entries(obj)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join('&')
}

// ---------------------------------------------------------------- OAuth

/** 產生同意畫面網址。必須在「中樞這台機器」的瀏覽器打開，redirect 才回得來。 */
function authUrl(clientId, redirectUri) {
  const q = form({
    client_id: clientId,
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: SCOPE,
    access_type: 'offline',      // 這個才會給 refresh token
    prompt: 'consent',           // 強制重新同意，確保一定拿得到 refresh token
    include_granted_scopes: 'true',
  })
  return `https://accounts.google.com/o/oauth2/v2/auth?${q}`
}

/** 用授權碼換 refresh token（只會成功一次，所以拿到要馬上存起來） */
async function exchangeCode({ clientId, clientSecret, code, redirectUri }) {
  const body = form({
    client_id: clientId,
    client_secret: clientSecret,
    code,
    grant_type: 'authorization_code',
    redirect_uri: redirectUri,
  })
  const r = await request({
    method: 'POST', host: 'oauth2.googleapis.com', path: '/token',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) },
  }, body)
  if (!r.refresh_token) {
    throw new Error('Google 沒有回傳 refresh token。請確認授權網址帶了 access_type=offline 與 prompt=consent，或先到 Google 帳號的「第三方應用程式」把舊授權移除再試一次。')
  }
  return r
}

/** refresh token → 短效 access token（每次上傳前呼叫） */
async function accessToken({ clientId, clientSecret, refreshToken }) {
  if (!clientId || !clientSecret || !refreshToken) throw new Error('尚未完成 Google 雲端授權')
  const body = form({
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
    grant_type: 'refresh_token',
  })
  const r = await request({
    method: 'POST', host: 'oauth2.googleapis.com', path: '/token',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(body) },
  }, body)
  return r.access_token
}

// ---------------------------------------------------------------- Drive API

async function about(token) {
  const r = await request({
    method: 'GET', host: 'www.googleapis.com',
    path: '/drive/v3/about?fields=user(emailAddress,displayName),storageQuota(limit,usage)',
    headers: { Authorization: `Bearer ${token}` },
  })
  const q = r.storageQuota ?? {}
  const gb = n => (Number(n || 0) / 1073741824).toFixed(1)
  return {
    email: r.user?.emailAddress ?? '(未知)',
    name: r.user?.displayName ?? '',
    usedGB: gb(q.usage),
    // limit 沒有回傳代表是無上限的方案
    totalGB: q.limit ? gb(q.limit) : null,
    freeGB: q.limit ? gb(Number(q.limit) - Number(q.usage || 0)) : null,
  }
}

/** 在 parent 底下找同名資料夾，沒有就建一個。回傳 folder id。 */
async function ensureFolder(token, name, parentId) {
  const safe = String(name).replace(/'/g, "\\'")
  const q = [
    `name='${safe}'`,
    `mimeType='${FOLDER_MIME}'`,
    'trashed=false',
    parentId ? `'${parentId}' in parents` : "'root' in parents",
  ].join(' and ')

  const found = await request({
    method: 'GET', host: 'www.googleapis.com',
    path: `/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)&pageSize=1`,
    headers: { Authorization: `Bearer ${token}` },
  })
  if (found.files?.length) return found.files[0].id

  const body = JSON.stringify({
    name: String(name), mimeType: FOLDER_MIME,
    parents: [parentId || 'root'],
  })
  const made = await request({
    method: 'POST', host: 'www.googleapis.com', path: '/drive/v3/files?fields=id',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body),
    },
  }, body)
  return made.id
}

/** 一路建到底：['小滿茶屋POS','中山店','北部','2026','咖啡節','2026-08-17'] */
async function ensureFolderPath(token, names) {
  let parent = null
  for (const n of names.filter(Boolean)) parent = await ensureFolder(token, n, parent)
  return parent
}

/**
 * 上傳檔案（multipart）。同名檔案直接覆寫，補傳不會產生一堆重複檔。
 * 回傳的 size 用來跟本地檔案比對 —— 大小一致才算真的上傳成功。
 */
async function uploadFile(token, parentId, name, buf) {
  // 先看看同名檔案在不在
  const safe = String(name).replace(/'/g, "\\'")
  const q = `name='${safe}' and '${parentId}' in parents and trashed=false`
  const found = await request({
    method: 'GET', host: 'www.googleapis.com',
    path: `/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id)&pageSize=1`,
    headers: { Authorization: `Bearer ${token}` },
  })
  const existingId = found.files?.[0]?.id

  const boundary = '----marketpos' + Date.now()
  const meta = existingId
    ? JSON.stringify({ name: String(name) })                       // 更新時不能再帶 parents
    : JSON.stringify({ name: String(name), parents: [parentId] })

  const head = Buffer.from(
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n` +
    `--${boundary}\r\nContent-Type: application/octet-stream\r\n\r\n`, 'utf8')
  const tail = Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8')
  const body = Buffer.concat([head, Buffer.from(buf), tail])

  const r = await request({
    method: existingId ? 'PATCH' : 'POST',
    host: 'www.googleapis.com',
    path: existingId
      ? `/upload/drive/v3/files/${existingId}?uploadType=multipart&fields=id,name,size`
      : '/upload/drive/v3/files?uploadType=multipart&fields=id,name,size',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': `multipart/related; boundary=${boundary}`,
      'Content-Length': body.length,
    },
  }, body)

  return { fileid: r.id, name: r.name, size: Number(r.size ?? buf.length) }
}

module.exports = { SCOPE, authUrl, exchangeCode, accessToken, about, ensureFolderPath, uploadFile }
