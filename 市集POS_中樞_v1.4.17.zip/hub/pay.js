/**
 * 線上金流（LINE Pay）── 只跑在中樞這一台
 * ============================================================
 * 這個檔案存在的唯一理由是**資安**。
 *
 * LINE Pay 的 Channel Secret 是一把可以直接請款的鑰匙。
 * 它絕對不能出現在：
 *   · 前端 JavaScript（打開開發者工具就看得到）
 *   · 給客人掃的自助下單頁（那是最不受控的裝置）
 *   · 開源出去的原始碼與任何設定檔範例
 *   · Supabase／Google Drive 這些會被同步出去的地方
 *
 * 所以整套簽章與呼叫都關在中樞裡：
 *   前端只會送「這一單多少錢」，拿回一個付款網址；
 *   金鑰從頭到尾沒有離開過中樞的硬碟。
 *
 * 讀設定的 API 一律回傳遮蔽過的值（hasSecret: true／'已設定'），
 * 前端永遠拿不到原文 —— 連管理員的 iPad 也拿不到。
 *
 * 還沒申請到 LINE Pay 也沒關係：整套流程都在，
 * 填了 Channel ID 與 Secret 就會真的送出去，沒填就回「尚未啟用」。
 * 這樣客戶拿到 API 的那一天，只要貼上兩個欄位就開始收錢，不用再改程式。
 */

const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

const PROD = 'https://api-pay.line.me'
const SANDBOX = 'https://sandbox-api-pay.line.me'

function file(dataDir, name) { return path.join(dataDir, name) }

function readJson(f, fallback) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')) } catch { return fallback }
}
function writeJsonAtomic(f, obj) {
  const tmp = f + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), { mode: 0o600 })
  fs.renameSync(tmp, f)
}

const DEFAULTS = {
  provider: 'linepay',
  enabled: false,
  channelId: '',
  channelSecret: '',
  sandbox: true,
  /** 付完款要跳回哪裡；留空就用送出請求時帶的網址 */
  confirmUrl: '',
  currency: 'TWD',
}

function loadConfig(dataDir) {
  return { ...DEFAULTS, ...readJson(file(dataDir, 'pay.json'), {}) }
}

function saveConfig(dataDir, patch) {
  const next = { ...loadConfig(dataDir), ...patch }
  writeJsonAtomic(file(dataDir, 'pay.json'), next)
  return publicConfig(dataDir)
}

/** 給前端看的版本：金鑰只回報「有沒有設定」，永遠不回原文 */
function publicConfig(dataDir) {
  const c = loadConfig(dataDir)
  return {
    provider: c.provider,
    enabled: Boolean(c.enabled),
    channelId: c.channelId ? c.channelId.slice(0, 4) + '••••' : '',
    hasChannelId: Boolean(c.channelId),
    hasSecret: Boolean(c.channelSecret),
    sandbox: Boolean(c.sandbox),
    confirmUrl: c.confirmUrl || '',
    currency: c.currency || 'TWD',
    ready: Boolean(c.enabled && c.channelId && c.channelSecret),
  }
}

/**
 * LINE Pay v3 的簽章：
 *   HMAC-SHA256( ChannelSecret , ChannelSecret + URI + Body + Nonce )
 * 這一段就是絕對不能離開中樞的東西。
 */
function sign(secret, uri, body, nonce) {
  return crypto.createHmac('sha256', secret)
    .update(secret + uri + body + nonce)
    .digest('base64')
}

function postJson(base, uri, headers, bodyStr, timeoutMs = 15000) {
  const url = new URL(base + uri)
  const https = require('https')
  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(bodyStr),
        ...headers,
      },
      timeout: timeoutMs,
    }, res => {
      const chunks = []
      res.on('data', c => chunks.push(c))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        try { resolve(JSON.parse(text)) }
        catch { reject(new Error('LINE Pay 回應不是 JSON：' + text.slice(0, 200))) }
      })
    })
    req.on('timeout', () => { req.destroy(new Error('連線逾時')) })
    req.on('error', reject)
    req.end(bodyStr)
  })
}

async function call(cfg, uri, payload) {
  const base = cfg.sandbox ? SANDBOX : PROD
  const nonce = crypto.randomUUID()
  const body = JSON.stringify(payload)
  return postJson(base, uri, {
    'X-LINE-ChannelId': cfg.channelId,
    'X-LINE-Authorization-Nonce': nonce,
    'X-LINE-Authorization': sign(cfg.channelSecret, uri, body, nonce),
  }, body)
}

// ---------------------------------------------------------------- 付款意圖

/**
 * 每一次要收錢就是一個 intent。留著它是為了「客人說付了、我們這邊沒看到」——
 * 那時要查的是這張表，不是去翻 LINE 的後台。
 */
function readIntents(dataDir) { return readJson(file(dataDir, 'payments.json'), []) }

function saveIntent(dataDir, intent) {
  const list = readIntents(dataDir)
  const i = list.findIndex(x => x.id === intent.id)
  if (i >= 0) list[i] = intent
  else list.unshift(intent)
  // 只留最近 500 筆，中樞跑在手機上，不能無限長大
  writeJsonAtomic(file(dataDir, 'payments.json'), list.slice(0, 500))
  return intent
}

function getIntent(dataDir, id) {
  return readIntents(dataDir).find(x => x.id === id) ?? null
}

/**
 * 送出付款請求，拿回讓客人跳轉的網址。
 * amount 一律以中樞這邊算出來的為準 —— 前端傳來的金額只當參考，
 * 不然改一改 JavaScript 就能用 1 元買珍奶。
 */
async function request(dataDir, { id, amount, productName, packages, confirmUrl, cancelUrl }) {
  const cfg = loadConfig(dataDir)
  if (!cfg.enabled || !cfg.channelId || !cfg.channelSecret) {
    return { ok: false, reason: 'not_configured', message: 'LINE Pay 尚未設定，請改用現場付款' }
  }
  if (!(amount > 0)) return { ok: false, reason: 'bad_amount', message: '金額不正確' }

  const orderId = id || ('pay_' + Date.now())
  const payload = {
    amount: Math.round(amount),
    currency: cfg.currency || 'TWD',
    orderId,
    packages: packages?.length ? packages : [{
      id: orderId, amount: Math.round(amount), name: productName || '現場訂單',
      products: [{ name: productName || '現場訂單', quantity: 1, price: Math.round(amount) }],
    }],
    redirectUrls: {
      confirmUrl: cfg.confirmUrl || confirmUrl,
      cancelUrl: cancelUrl || confirmUrl,
    },
  }

  let res
  try {
    res = await call(cfg, '/v3/payments/request', payload)
  } catch (e) {
    return { ok: false, reason: 'network', message: e.message }
  }

  const ok = res?.returnCode === '0000'
  const intent = saveIntent(dataDir, {
    id: orderId,
    provider: 'linepay',
    amount: Math.round(amount),
    status: ok ? 'pending' : 'failed',
    transactionId: res?.info?.transactionId ? String(res.info.transactionId) : '',
    paymentUrl: res?.info?.paymentUrl?.web ?? '',
    appUrl: res?.info?.paymentUrl?.app ?? '',
    returnCode: res?.returnCode ?? '',
    message: res?.returnMessage ?? '',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  })

  if (!ok) return { ok: false, reason: 'provider', message: res?.returnMessage || '付款請求被拒絕', intent }
  return { ok: true, intent }
}

/** 客人付完款跳回來時呼叫，這一步才是真的請款 */
async function confirm(dataDir, { id, transactionId }) {
  const cfg = loadConfig(dataDir)
  const intent = getIntent(dataDir, id)
  if (!intent) return { ok: false, message: '找不到這筆付款' }
  if (intent.status === 'paid') return { ok: true, intent }

  const txn = transactionId || intent.transactionId
  if (!txn) return { ok: false, message: '缺少交易編號' }

  let res
  try {
    res = await call(cfg, `/v3/payments/${txn}/confirm`, {
      amount: intent.amount, currency: cfg.currency || 'TWD',
    })
  } catch (e) {
    return { ok: false, message: e.message }
  }

  const ok = res?.returnCode === '0000'
  const next = saveIntent(dataDir, {
    ...intent,
    status: ok ? 'paid' : 'failed',
    returnCode: res?.returnCode ?? '',
    message: res?.returnMessage ?? '',
    paidAt: ok ? Date.now() : undefined,
    updatedAt: Date.now(),
  })
  return { ok, intent: next, message: res?.returnMessage ?? '' }
}

module.exports = {
  loadConfig, saveConfig, publicConfig,
  request, confirm, getIntent, readIntents, saveIntent,
  sign,           // 匯出只為了測試簽章演算法，不對外開 API
}
