@echo off
chcp 65001 >nul
title 市集 POS - 攤位中樞
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   找不到 Node.js
  echo   請先到 https://nodejs.org 下載 LTS 版安裝，安裝完再執行這個檔案。
  echo.
  pause
  exit /b 1
)

echo.
echo   正在啟動攤位中樞... 這個視窗請不要關閉。
echo.
node hub.js
pause
