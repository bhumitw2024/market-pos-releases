/**
 * 收攤備份
 * ============================================================
 * 流程：產生封存檔 → 上傳 Google 雲端硬碟 → 驗證大小 → 才刪本地暫存 → 記錄
 *
 * 安全原則（很重要）：
 *   1. 沒有「確認上傳成功」之前，絕對不刪任何東西。
 *   2. 上傳失敗會排進待上傳佇列，有網路時自動重試。
 *   3. 精簡本地訂單只會動「已確認上傳」且超過保留天數的資料，
 *      今天與進行中的場次永遠留著。
 *
 * Google 雲端硬碟資料夾結構（第十一輪回報第 1 項）：
 *   /<品牌>POS/{店面,場次}/<店面或場次名稱>/<年度>/<月份>/<營業日>/
 *      orders.csv, orders.jsonl, summary.json, config.json
 *
 * 憑證（refresh token）只存在中樞這一台，API 回傳一律遮罩，不會下發給任何 iPad。
 */

const fs = require('fs')
const path = require('path')
const gdrive = require('./gdrive')

/** 當地日期，不用 UTC —— 否則凌晨會算成前一天 */
function localDate(d = new Date()) {
  const p = n => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

const PAY_LABEL = { cash: '現金', linepay: 'LINE Pay', voucher: '折價券', other: '其他' }

// ---------------------------------------------------------------- 設定

function cfgFile(dataDir) { return path.join(dataDir, 'backup-config.json') }
function logFile(dataDir) { return path.join(dataDir, 'backup-log.json') }

const DEFAULT_CFG = {
  enabled: false,
  provider: 'gdrive',
  // Google OAuth：在 Google Cloud Console 建一個「桌面應用程式」用戶端
  clientId: '',
  clientSecret: '',
  refreshToken: '',          // 只存在中樞，API 回傳一律遮罩
  rootFolder: '市集POS',
  deleteLocalAfterUpload: true,   // 上傳成功後刪掉本地封存暫存檔
  pruneOrders: false,             // 是否精簡 orders.jsonl
  keepDays: 90,                   // 精簡時保留最近幾天
}

function readJson(f, fallback) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')) } catch { return fallback }
}
function writeJsonAtomic(f, obj) {
  const tmp = f + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2))
  fs.renameSync(tmp, f)
}

function loadConfig(dataDir) {
  return { ...DEFAULT_CFG, ...readJson(cfgFile(dataDir), {}) }
}
function saveConfig(dataDir, patch) {
  const next = { ...loadConfig(dataDir), ...patch }
  writeJsonAtomic(cfgFile(dataDir), next)
  return next
}
/** 對外一律遮蔽憑證，不讓它出現在任何 API 回應裡 */
function publicConfig(dataDir) {
  const c = loadConfig(dataDir)
  return {
    ...c,
    clientSecret: c.clientSecret ? '已設定' : '',
    refreshToken: c.refreshToken ? `已授權（${c.refreshToken.slice(0, 6)}…）` : '',
    hasAuth: Boolean(c.refreshToken),
    hasClient: Boolean(c.clientId && c.clientSecret),
    account: c.account ?? '',
  }
}

function loadLog(dataDir) {
  return readJson(logFile(dataDir), { runs: [], pending: [] })
}
function saveLog(dataDir, log) {
  log.runs = log.runs.slice(-200)
  writeJsonAtomic(logFile(dataDir), log)
}

// ---------------------------------------------------------------- 封存內容

function csvEscape(v) { return `"${String(v ?? '').replace(/"/g, '""')}"` }

function buildCsv(orders, cashFloat) {
  const rows = []
  rows.push(['【交易明細】'])
  rows.push(['營業日', '序號', '裝置', '時間', '品項', '選項', '備註', '數量', '單價', '原價',
    '小計', '成本', '訂單總額', '折扣', '付款明細', '客群', '來源', '狀態'])
  for (const o of orders) {
    const pay = (o.payments?.length ? o.payments : [{ method: o.payMethod, amount: o.total }])
      .map(p => `${PAY_LABEL[p.method] ?? p.method}${p.amount}`).join('+')
    const tags = Object.values(o.customerTags ?? {}).filter(Boolean).join('/')
    for (const it of o.items ?? []) {
      rows.push([
        o.bizDate, o.serialText, o.deviceCode,
        new Date(o.createdAt).toLocaleString('zh-TW'),
        it.productName,
        (it.options ?? []).map(x => x.choiceName).join(' / '),
        it.note, it.qty, it.unitPrice, it.listPrice ?? it.unitPrice,
        it.unitPrice * it.qty, (it.unitCost ?? 0) * it.qty,
        o.total, o.discount ?? 0, pay, tags,
        o.channel === 'self' ? '客人自助' : '店員', o.status,
      ])
    }
  }
  if (cashFloat) {
    rows.push([])
    rows.push(['【零用金面額明細】'])
    rows.push(['面額', '數量', '小計'])
    for (const e of (cashFloat.entries ?? []).filter(x => x.count > 0)) {
      rows.push([e.denom, e.count, e.denom * e.count])
    }
    rows.push(['合計', '', (cashFloat.entries ?? []).reduce((a, e) => a + e.denom * e.count, 0)])
    if (cashFloat.note) rows.push(['備註', cashFloat.note])
  }
  return '﻿' + rows.map(r => r.map(csvEscape).join(',')).join('\r\n')
}

function buildSummary(orders, cashFloat, projectName, bizDate) {
  const live = orders.filter(o => o.status !== 'void')
  const voided = orders.filter(o => o.status === 'void')
  const revenue = live.reduce((a, o) => a + o.total, 0)
  const cost = live.reduce((a, o) => a + (o.cost ?? 0), 0)
  const cups = live.reduce((a, o) => a + o.totalQty, 0)

  const byPay = {}
  for (const o of live) {
    const parts = o.payments?.length ? o.payments : [{ method: o.payMethod, amount: o.total }]
    for (const p of parts) byPay[p.method] = (byPay[p.method] ?? 0) + p.amount
  }
  const byProduct = {}
  for (const o of live) for (const it of o.items ?? []) {
    const e = byProduct[it.productName] ?? { qty: 0, revenue: 0, cost: 0 }
    e.qty += it.qty; e.revenue += it.unitPrice * it.qty; e.cost += (it.unitCost ?? 0) * it.qty
    byProduct[it.productName] = e
  }
  const byHour = {}
  for (const o of live) {
    const h = new Date(o.createdAt).getHours()
    const e = byHour[h] ?? { revenue: 0, cups: 0 }
    e.revenue += o.total; e.cups += o.totalQty
    byHour[h] = e
  }
  const byTag = {}
  for (const o of live) {
    for (const [k, v] of Object.entries(o.customerTags ?? {})) {
      if (!v) continue
      byTag[k] = byTag[k] ?? {}
      byTag[k][v] = (byTag[k][v] ?? 0) + o.total
    }
  }
  const floatTotal = (cashFloat?.entries ?? []).reduce((a, e) => a + e.denom * e.count, 0)

  return {
    專案: projectName,
    營業日: bizDate,
    產生時間: new Date().toISOString(),
    訂單筆數: live.length,
    作廢筆數: voided.length,
    總杯數: cups,
    總營收: revenue,
    成本: cost,
    毛利: revenue - cost,
    毛利率: revenue ? Math.round(((revenue - cost) / revenue) * 1000) / 10 : 0,
    客單價: live.length ? Math.round(revenue / live.length) : 0,
    折扣讓利: live.reduce((a, o) => a + (o.discount ?? 0), 0),
    付款方式: byPay,
    零用金: { 合計: floatTotal, 面額: cashFloat?.entries ?? [], 備註: cashFloat?.note ?? '' },
    收班應有現金: floatTotal + (byPay.cash ?? 0),
    品項分析: byProduct,
    時段分析: byHour,
    客群分析: byTag,
  }
}

// ---------------------------------------------------------------- 其他報表

function costTypeOf(category, posConfig) {
  const c = (posConfig?.settings?.expenseCategories ?? posConfig?.expenseCategories ?? [])
    .find(x => x.name === category)
  return c?.costType === 'cogs' ? 'cogs' : 'opex'
}

/** 營運日報：收班對帳要的那幾個數字，跟畫面上那一頁對得起來 */
function buildDailyRows(orders, expenses, cashFloat, tag, bizDate, posConfig) {
  const live = orders.filter(o => o.status !== 'void')
  const revenue = live.reduce((a, o) => a + o.total, 0)
  const itemCost = live.reduce((a, o) => a + (o.cost ?? 0), 0)
  const cups = live.reduce((a, o) => a + o.totalQty, 0)
  const cogs = expenses.filter(e => costTypeOf(e.category, posConfig) === 'cogs')
    .reduce((a, e) => a + e.amount, 0)
  const opex = expenses.reduce((a, e) => a + e.amount, 0) - cogs
  const cashOut = expenses.filter(e => e.payMethod === 'cash' && e.paid).reduce((a, e) => a + e.amount, 0)

  const byPay = {}
  const byPayCount = {}
  for (const o of live) {
    const parts = o.payments?.length ? o.payments : [{ method: o.payMethod, amount: o.total }]
    const seen = new Set()
    for (const p of parts) {
      byPay[p.method] = (byPay[p.method] ?? 0) + p.amount
      if (!seen.has(p.method)) { byPayCount[p.method] = (byPayCount[p.method] ?? 0) + 1; seen.add(p.method) }
    }
  }
  const floatTotal = (cashFloat?.entries ?? []).reduce((a, e) => a + e.denom * e.count, 0)

  const rows = []
  rows.push([`【營運日報】${tag}`, bizDate])
  rows.push([])
  rows.push(['項目', '金額', '說明'])
  rows.push(['總營收', revenue, `${live.length} 筆訂單・${cups} 杯`])
  rows.push(['商品成本', itemCost, '每杯設定的成本 × 賣出杯數'])
  rows.push(['支出（銷貨）', cogs, '進貨、包材、冰塊…'])
  rows.push(['支出（營業）', opex, '攤位費、租金、人事、交通…'])
  rows.push(['本期淨利', revenue - itemCost - cogs - opex, '營收 − 商品成本 − 全部支出'])
  rows.push(['作廢筆數', orders.length - live.length, ''])
  rows.push([])
  rows.push(['【收款拆帳】'])
  rows.push(['付款方式', '金額', '筆數'])
  for (const k of ['cash', 'linepay', 'voucher', 'other']) {
    if (!byPay[k]) continue
    rows.push([PAY_LABEL[k] ?? k, byPay[k], byPayCount[k] ?? 0])
  }
  rows.push([])
  rows.push(['【現金對帳】'])
  rows.push(['開帳零用金', floatTotal, ''])
  rows.push(['現金收入', byPay.cash ?? 0, ''])
  rows.push(['現金支出', -cashOut, '今天直接從錢箱付掉的'])
  rows.push(['收班應有現金', floatTotal + (byPay.cash ?? 0) - cashOut, '數錢箱要對到這個數字'])

  const byHour = {}
  for (const o of live) {
    const h = new Date(o.createdAt).getHours()
    const e = byHour[h] ?? { revenue: 0, cups: 0, orders: 0 }
    e.revenue += o.total; e.cups += o.totalQty; e.orders += 1
    byHour[h] = e
  }
  rows.push([])
  rows.push(['【時段分析】'])
  rows.push(['時段', '訂單', '杯數', '營收'])
  for (const h of Object.keys(byHour).sort((a, b) => a - b)) {
    rows.push([`${String(h).padStart(2, '0')}:00`, byHour[h].orders, byHour[h].cups, byHour[h].revenue])
  }
  return rows
}

/** 產品分析：哪幾款賣得動、哪幾款在佔位置 */
function buildProductRows(orders) {
  const live = orders.filter(o => o.status !== 'void')
  const m = {}
  const addons = {}
  for (const o of live) {
    for (const it of o.items ?? []) {
      const e = m[it.productName] ?? { qty: 0, revenue: 0, cost: 0 }
      e.qty += it.qty
      e.revenue += it.unitPrice * it.qty
      e.cost += (it.unitCost ?? 0) * it.qty
      m[it.productName] = e
      for (const op of it.options ?? []) {
        if (!op.priceDelta || op.priceDelta <= 0) continue
        const a = addons[op.choiceName] ?? { qty: 0, revenue: 0 }
        a.qty += it.qty
        a.revenue += op.priceDelta * it.qty
        addons[op.choiceName] = a
      }
    }
  }
  const total = Object.values(m).reduce((a, e) => a + e.revenue, 0)
  const rows = [['【產品分析】'], [], ['品項', '杯數', '營收', '成本', '毛利', '毛利率%', '營收佔比%']]
  for (const [name, e] of Object.entries(m).sort((a, b) => b[1].revenue - a[1].revenue)) {
    rows.push([
      name, e.qty, e.revenue, e.cost, e.revenue - e.cost,
      e.revenue ? (((e.revenue - e.cost) / e.revenue) * 100).toFixed(1) : '0',
      total ? ((e.revenue / total) * 100).toFixed(1) : '0',
    ])
  }
  rows.push([])
  rows.push(['【加購分析】（只算會加價的選項）'])
  rows.push(['加購項目', '份數', '加購營收'])
  for (const [name, a] of Object.entries(addons).sort((x, y) => y[1].revenue - x[1].revenue)) {
    rows.push([name, a.qty, a.revenue])
  }
  return rows
}

/** 支出明細：歸屬寫到分店，不然分店損益永遠對不出來 */
function buildExpenseRows(expenses, posConfig) {
  const branchName = id => id
    ? ((posConfig?.branches ?? []).find(b => b.id === id)?.name ?? '已刪除的分店')
    : '未指定分店'
  const projName = id => id
    ? ((posConfig?.projects ?? []).find(p => p.id === id)?.name ?? '已刪除的場次')
    : '店面營運'

  const rows = [['【支出明細】'], [],
    ['日期', '歸屬分店', '歸屬場次', '類別', '成本性質', '品項', '廠商', '發票號碼',
      '單價', '數量', '金額', '支付方式', '經手人', '已付', '備註']]
  let cogs = 0, opex = 0
  for (const e of expenses) {
    const isCogs = costTypeOf(e.category, posConfig) === 'cogs'
    if (isCogs) cogs += e.amount; else opex += e.amount
    rows.push([
      e.date, branchName(e.branchId), projName(e.projectId),
      e.category, isCogs ? '銷貨成本' : '營業費用',
      e.name, e.vendor ?? '', e.invoiceNo ?? '',
      e.unitPrice ?? '', e.qty ?? '', e.amount,
      e.payMethod ?? '', e.staff ?? '', e.paid ? '已付' : '未付', e.note ?? '',
    ])
  }
  rows.push([])
  rows.push(['銷貨成本合計', cogs])
  rows.push(['營業費用合計', opex])
  rows.push(['支出總計', cogs + opex])
  return rows
}

/** 損益表：跟前台損益表同一套算法（營收 − 銷貨成本 = 毛利，毛利 − 營業費用 = 淨利） */
function buildPnlRows(orders, expenses, posConfig, tag, periodLabel) {
  const live = orders.filter(o => o.status !== 'void')
  const revenue = live.reduce((a, o) => a + o.total, 0)
  const itemCost = live.reduce((a, o) => a + (o.cost ?? 0), 0)
  const cups = live.reduce((a, o) => a + o.totalQty, 0)
  const discount = live.reduce((a, o) => a + (o.discount ?? 0), 0)
  const cogsExpense = expenses.filter(e => costTypeOf(e.category, posConfig) === 'cogs').reduce((a, e) => a + e.amount, 0)
  const opexExpense = expenses.filter(e => costTypeOf(e.category, posConfig) === 'opex').reduce((a, e) => a + e.amount, 0)
  const totalCogs = itemCost + cogsExpense
  const gross = revenue - totalCogs
  const net = gross - opexExpense

  const rows = [[`【損益表】${tag}`, periodLabel], []]
  rows.push(['項目', '金額', '說明'])
  rows.push(['營收', revenue, `${live.length} 筆訂單・${cups} 杯`])
  rows.push(['商品成本（賣出時的杯子成本）', itemCost, ''])
  rows.push(['其他銷貨成本（支出分類為銷貨）', cogsExpense, ''])
  rows.push(['銷貨成本合計', totalCogs, ''])
  rows.push(['毛利', gross, revenue ? `毛利率 ${((gross / revenue) * 100).toFixed(1)}%` : ''])
  rows.push(['營業費用', opexExpense, ''])
  rows.push(['淨利', net, ''])
  rows.push(['折扣讓利', discount, ''])
  rows.push(['客單價', live.length ? Math.round(revenue / live.length) : 0, ''])
  return rows
}

/** TA 分析表：成交時段 ＋ 各客群分析（跟前台 TAReport.tsx 同一套算法） */
function buildTaRows(orders, posConfig) {
  const live = orders.filter(o => o.status !== 'void')
  const revenue = live.reduce((a, o) => a + o.total, 0)

  const byHour = new Map()
  for (const o of live) {
    const h = new Date(o.createdAt).getHours()
    const e = byHour.get(h) ?? { hour: h, revenue: 0, cups: 0, orders: 0 }
    e.revenue += o.total; e.cups += o.totalQty; e.orders += 1
    byHour.set(h, e)
  }
  const hours = [...byHour.values()].sort((a, b) => a.hour - b.hour)

  const rows = [['【TA 分析表】'], []]
  rows.push(['【成交時段】'])
  rows.push(['時段', '訂單數', '杯數', '營收', '佔比%'])
  for (const h of hours) {
    rows.push([`${String(h.hour).padStart(2, '0')}:00`, h.orders, h.cups, h.revenue,
      revenue ? ((h.revenue / revenue) * 100).toFixed(1) : '0'])
  }

  const tagGroups = (posConfig?.settings?.customerTagGroups ?? posConfig?.customerTagGroups ?? [])
  for (const g of tagGroups) {
    const m = new Map()
    for (const o of live) {
      const v = o.customerTags?.[g.key] || '未填'
      const e = m.get(v) ?? { name: v, revenue: 0, cups: 0, orders: 0 }
      e.revenue += o.total; e.cups += o.totalQty; e.orders += 1
      m.set(v, e)
    }
    const tagRows = [...m.values()].sort((a, b) => b.revenue - a.revenue)
    rows.push([])
    rows.push([`【${g.name}】`])
    rows.push([g.name, '訂單數', '杯數', '營收', '佔比%', '客單價'])
    for (const r of tagRows) {
      rows.push([r.name, r.orders, r.cups, r.revenue,
        revenue ? ((r.revenue / revenue) * 100).toFixed(1) : '0',
        r.orders ? Math.round(r.revenue / r.orders) : 0])
    }
  }
  return rows
}

const PREP_PHASE_LABEL_HUB = { open: '開攤點交', add: '中途補充', loss: '中途損耗', close: '收攤點交' }

/** 備料明細表：彙總（開攤＋補充－損耗－收攤剩＝實際用掉）＋ 每一次點交的流水 */
function buildPrepRows(prepCounts, prepItems, tag, periodLabel) {
  const items = prepItems ?? []
  const counts = prepCounts ?? []
  const balance = items.map(it => {
    const sumOf = phase => counts.filter(c => c.phase === phase)
      .reduce((a, c) => a + (c.lines.find(l => l.itemId === it.id)?.qty ?? 0), 0)
    const open = sumOf('open'), add = sumOf('add'), loss = sumOf('loss'), closed = sumOf('close')
    return { it, open, add, loss, closed, used: open + add - loss - closed }
  }).filter(r => r.open || r.add || r.loss || r.closed)

  const rows = [[`【備料明細表】${tag}`, periodLabel], []]
  rows.push(['【彙總】'])
  rows.push(['物料品項', '開攤點交', '中途補充', '中途損耗', '收攤剩下', '實際用掉'])
  for (const b of balance) rows.push([b.it.name, b.open, b.add, b.loss, b.closed, b.used])
  rows.push([])
  rows.push(['【點交流水】'])
  rows.push(['營業日', '階段', '時間', '經手人', '品項與數量', '備註'])
  for (const c of [...counts].sort((a, b) => a.createdAt - b.createdAt)) {
    const lines = (c.lines ?? []).filter(l => l.qty)
      .map(l => `${items.find(i => i.id === l.itemId)?.name ?? '（已刪除）'} × ${l.qty}`)
    rows.push([c.bizDate, PREP_PHASE_LABEL_HUB[c.phase] ?? c.phase,
      new Date(c.createdAt).toLocaleString('zh-TW'), c.staff ?? '', lines.join(' / '), c.note ?? ''])
  }
  return rows
}

// ---------------------------------------------------------------- 主流程

/**
 * 一次收攤要上傳哪些檔案
 * ============================================================
 * 以前只有 orders.csv / orders.jsonl / summary.json / config.json。
 * 檔名全部一樣，下載十個場次到電腦上就是十個 orders.csv，
 * 根本分不出哪個是哪個 —— 所以現在每個檔名前面都帶攤位名稱：
 *
 *   文創市集-交易明細.csv
 *   文創市集-營運日報.csv
 *   文創市集-產品分析.csv
 *   文創市集-支出明細.csv
 *   文創市集-結算摘要.json
 *   文創市集-原始訂單.jsonl
 *   文創市集-設定快照.json
 *
 * 「交易明細」是使用者自己用的詞，就照他的詞命名。
 */
function buildBundle(tag, orders, expenses, cashFloat, posConfig, bizDate) {
  const t = sanitizeSeg(tag)
  const j = obj => Buffer.from(JSON.stringify(obj, null, 2), 'utf8')
  const c = rows => Buffer.from('﻿' + rows.map(r => r.map(csvEscape).join(',')).join('\r\n'), 'utf8')
  return [
    { name: `${t}-交易明細.csv`, buf: Buffer.from(buildCsv(orders, cashFloat), 'utf8') },
    { name: `${t}-營運日報.csv`, buf: c(buildDailyRows(orders, expenses, cashFloat, tag, bizDate, posConfig)) },
    { name: `${t}-產品分析.csv`, buf: c(buildProductRows(orders)) },
    { name: `${t}-支出明細.csv`, buf: c(buildExpenseRows(expenses, posConfig)) },
    { name: `${t}-結算摘要.json`, buf: j(buildSummary(orders, cashFloat, tag, bizDate)) },
    { name: `${t}-原始訂單.jsonl`, buf: Buffer.from(orders.map(o => JSON.stringify(o)).join('\n'), 'utf8') },
    { name: `${t}-設定快照.json`, buf: j(posConfig ?? {}) },
  ]
}

/**
 * 這次收攤要結算「哪一攤」。
 * ------------------------------------------------------------
 * projectId 現在有三種寫法（舊的照樣支援）：
 *   'all'            今天全部分店＋全部場次（品牌總結）
 *   'branch:<id>'    某一家分店的店面營運（不含它去擺攤的部分）
 *   'default' / ''   沒指定分店、也沒有場次的那些單
 *   '<場次 id>'      某一個場次
 *
 * 分店必須能單獨結算 —— 三家店的錢箱是分開的，
 * 數字加在一起就沒有人對得起來。
 */
function selectorFor(projectId, posConfig) {
  const hasEvent = r => Boolean(r.projectId) && r.projectId !== 'default'

  if (projectId === 'all') {
    return { tag: '全部攤位', scopeKey: 'all', match: () => true }
  }
  if (String(projectId || '').startsWith('branch:')) {
    const id = String(projectId).slice(7)
    const b = (posConfig?.branches ?? []).find(x => x.id === id)
    return {
      tag: b?.name || id,
      scopeKey: projectId,
      match: r => r.branchId === id && !hasEvent(r),
    }
  }
  if (!projectId || projectId === 'default') {
    return { tag: '店面', scopeKey: 'default', match: r => !r.branchId && !hasEvent(r) }
  }
  const proj = (posConfig?.projects ?? []).find(p => p.id === projectId)
  return {
    tag: proj?.name || projectId,
    scopeKey: projectId,
    match: r => r.projectId === projectId,
  }
}

/**
 * @param ctx { dataDir, readOrders, readConfig, readCashFloat, projectName }
 */
async function runBackup(ctx, { projectId, bizDate }) {
  const { dataDir } = ctx
  const cfg = loadConfig(dataDir)
  if (!cfg.refreshToken) throw new Error('尚未完成 Google 雲端授權')

  const posConfig = ctx.readConfig()
  const sel = selectorFor(projectId, posConfig)
  const all = ctx.readOrders()
  const orders = all.filter(o => o.bizDate === bizDate && sel.match(o))
  const expenses = (posConfig?.expenses ?? []).filter(e => e.date === bizDate && sel.match(e))
  const projectName = sel.tag
  const cashFloat = ctx.readCashFloat(projectId, bizDate, posConfig)

  // {店面,場次} / 名稱 / 年度 / 月份 / 營業日 —— 舊版沒有 scopeOf 就退回一個簡單的兩層
  const scope = ctx.scopeOf
    ? ctx.scopeOf(projectId, posConfig, bizDate)
    : { kind: '店面', name: projectName, year: bizDate.slice(0, 4), month: bizDate.slice(5, 7) }
  const segs = [scope.kind, scope.name, scope.year, scope.month, bizDate].map(sanitizeSeg)

  const files = buildBundle(projectName, orders, expenses, cashFloat, posConfig, bizDate)

  // 先寫成本地暫存，萬一上傳中途失敗，檔案還在，重試不用重算
  const stageDir = path.join(dataDir, 'backup', ...segs)
  fs.mkdirSync(stageDir, { recursive: true })
  for (const f of files) fs.writeFileSync(path.join(stageDir, f.name), f.buf)

  const log = loadLog(dataDir)
  const run = {
    at: Date.now(), projectId, projectName, bizDate,
    orders: orders.length,
    bytes: files.reduce((a, f) => a + f.buf.length, 0),
    ok: false, files: [], error: null,
  }

  try {
    const token = await gdrive.accessToken(cfg)
    const folderid = await gdrive.ensureFolderPath(token, [cfg.rootFolder, ...segs])
    for (const f of files) {
      const r = await gdrive.uploadFile(token, folderid, f.name, f.buf)
      // 大小對不上就當作沒傳成功，寧可留著本地檔案也不要以為備份好了
      if (Number(r.size) !== f.buf.length) {
        throw new Error(`${f.name} 上傳後大小不符（雲端 ${r.size} / 本地 ${f.buf.length}），已中止，本地檔案保留`)
      }
      run.files.push({ name: f.name, size: r.size, fileid: r.fileid })
    }
    run.ok = true

    // ---- 確認全部上傳成功，才動本地檔案 ----
    if (cfg.deleteLocalAfterUpload) {
      fs.rmSync(stageDir, { recursive: true, force: true })
      run.stageDeleted = true
    }
    log.pending = (log.pending ?? []).filter(p => !(p.projectId === projectId && p.bizDate === bizDate))
  } catch (e) {
    run.error = e.message
    const pending = (log.pending ?? []).filter(p => !(p.projectId === projectId && p.bizDate === bizDate))
    pending.push({ projectId, bizDate, projectName, lastError: e.message, at: Date.now() })
    log.pending = pending
  }

  log.runs.push(run)
  saveLog(dataDir, log)
  return run
}

/**
 * 精簡本地訂單：只移除「已確認上傳成功」且早於保留天數的資料。
 * 回傳實際移除筆數。orders.jsonl 會被整份重寫（先寫暫存再改名，斷電安全）。
 */
function pruneOrders(ctx, { ordersFile }) {
  const { dataDir } = ctx
  const cfg = loadConfig(dataDir)
  if (!cfg.pruneOrders) return { removed: 0, reason: '未啟用精簡' }

  const log = loadLog(dataDir)
  const uploaded = new Set(log.runs.filter(r => r.ok).map(r => `${r.projectId}|${r.bizDate}`))
  const cutoff = localDate(new Date(Date.now() - cfg.keepDays * 86400000))
  const today = localDate()

  const all = ctx.readOrders()
  const keep = all.filter(o => {
    if (o.bizDate >= cutoff) return true                    // 還在保留期內
    if (o.bizDate === today) return true                    // 今天永遠留著
    if (!uploaded.has(`${o.projectId}|${o.bizDate}`)) return true   // 沒確認上傳過就不動
    return false
  })
  const removed = all.length - keep.length
  if (removed > 0) {
    const tmp = ordersFile + '.tmp'
    fs.writeFileSync(tmp, keep.map(o => JSON.stringify(o)).join('\n') + (keep.length ? '\n' : ''))
    fs.renameSync(tmp, ordersFile)
  }
  return { removed, keepDays: cfg.keepDays, cutoff }
}

/** 重試所有待上傳的日期（有網路時定期呼叫） */
async function retryPending(ctx) {
  const log = loadLog(ctx.dataDir)
  const pending = [...(log.pending ?? [])]
  const results = []
  for (const p of pending) {
    try { results.push(await runBackup(ctx, p)) } catch (e) { results.push({ ...p, ok: false, error: e.message }) }
  }
  return results
}

function status(dataDir) {
  const log = loadLog(dataDir)
  const runs = [...log.runs].reverse()
  return {
    config: publicConfig(dataDir),
    lastOk: runs.find(r => r.ok) ?? null,
    lastRun: runs[0] ?? null,
    pending: log.pending ?? [],
    recent: runs.slice(0, 10),
  }
}

function sanitizeSeg(s) {
  return String(s).replace(/[\\/:*?"<>|]/g, '_').trim() || 'default'
}

// ---------------------------------------------------------------- 月結自動上傳（第十一輪回報第 1 項）

/**
 * 月底自動上傳
 * ============================================================
 * 客戶要的是「每個月底自動打包一份完整報表上傳」，而且要處理好 2 月 28 號、
 * 30／31 天月份這些「月底到底是幾號」的問題。
 *
 * 這裡刻意**不去算「今天是不是月底」**（那樣 2 月要另外判斷、閏年又要再判斷一次，
 * 一年準備錯個一兩次），改成每天檢查一次「上個月」這個概念本身：
 *
 *     用 JS 的 Date(year, month, 1) 減一個月，物件自己會處理清楚
 *     1 月的「上個月」是去年 12 月、閏年 2 月有 29 天……這些全部交給 Date 運算，
 *     不用自己寫任何 if (month === 2) 這種特例判斷。
 *
 * 只要今天是「這個月的前幾天」（預設 5 天內），就檢查「上個月」是不是還沒上傳過，
 * 沒有的話就補一次。這樣就算中樞剛好在月底那天沒開機（攤位收攤、手機沒開 App），
 * 隔天、大後天開機一樣補得上，不會因為錯過那一天就永遠漏掉那個月。
 */
function monthlyLogFile(dataDir) { return path.join(dataDir, 'backup-monthly-log.json') }
function loadMonthlyLog(dataDir) { return readJson(monthlyLogFile(dataDir), { runs: [], doneMonths: [] }) }
function saveMonthlyLog(dataDir, log) {
  log.runs = (log.runs ?? []).slice(-300)
  log.doneMonths = [...new Set(log.doneMonths ?? [])].slice(-36)
  writeJsonAtomic(monthlyLogFile(dataDir), log)
}

/** 'YYYY-MM' → 那個月第一天與最後一天（用 Date 自己算天數，2 月 28/29、30、31 天都不用特例判斷） */
function monthRangeOf(yearMonth) {
  const [y, m] = yearMonth.split('-').map(Number)
  const lastDay = new Date(y, m, 0).getDate()
  const p = n => String(n).padStart(2, '0')
  return { from: `${yearMonth}-01`, to: `${yearMonth}-${p(lastDay)}` }
}

/** 「上個月」是哪個月——一樣交給 Date 物件處理跨年（1 月的上個月是去年 12 月） */
function prevMonthOf(d = new Date()) {
  const pm = new Date(d.getFullYear(), d.getMonth() - 1, 1)
  return `${pm.getFullYear()}-${String(pm.getMonth() + 1).padStart(2, '0')}`
}

/** 今天是不是「這個月剛開始的前幾天」——月結檢查只在這個窗口內做，其餘時間不用每次都查 */
function isMonthStartWindow(daysWindow = 5, d = new Date()) {
  return d.getDate() <= daysWindow
}

/** 某個場次的營業期間跟這個月有沒有交集 —— 只替真的有在這個月營業過的場次結月報，不是每個場次都結 */
function monthOverlaps(p, yearMonth) {
  const { from, to } = monthRangeOf(yearMonth)
  const start = p.startDate || from
  const end = p.endDate || p.startDate || to
  return start <= to && end >= from
}

/** 整月的零用金加總（現金結算摘要用）——邏輯跟 hub.js 的 readCashFloat 同一套 key 對法，只是這裡是整月加總 */
function monthCashFloat(projectId, from, to, posConfig) {
  const all = (posConfig?.cashFloats ?? []).filter(f => f.bizDate >= from && f.bizDate <= to)
  if (!all.length) return null
  if (projectId === 'all') {
    return { entries: all.flatMap(f => f.entries ?? []), note: `${all.length} 筆零用金加總（整月）` }
  }
  const key = !projectId || projectId === 'default' ? 'default' : projectId
  const mine = all.filter(f => (f.projectId || 'default') === key)
  if (!mine.length) return null
  return { entries: mine.flatMap(f => f.entries ?? []), note: `${mine.length} 筆零用金加總（整月）` }
}

/**
 * 月結打包的檔案（跟收攤日結一樣，檔名帶攤位名稱，但標「月報」跟每天那份分開）。
 * 内容跟客戶要的六種一致：損益表、產品分析表、TA 分析表、營運日報、備料明細表、支出明細表。
 * 行銷活動、比較報表這幾種還沒做進自動上傳，見 buildMonthlyBundle 呼叫端的說明。
 */
function buildMonthlyBundle(tag, orders, expenses, cashFloat, prepCounts, prepItems, posConfig, yearMonth) {
  const t = sanitizeSeg(tag)
  const j = obj => Buffer.from(JSON.stringify(obj, null, 2), 'utf8')
  const c = rows => Buffer.from('﻿' + rows.map(r => r.map(csvEscape).join(',')).join('\r\n'), 'utf8')
  return [
    { name: `${t}-損益表(月報).csv`, buf: c(buildPnlRows(orders, expenses, posConfig, tag, yearMonth)) },
    { name: `${t}-產品分析表(月報).csv`, buf: c(buildProductRows(orders)) },
    { name: `${t}-TA分析表(月報).csv`, buf: c(buildTaRows(orders, posConfig)) },
    { name: `${t}-營運日報(月報).csv`, buf: c(buildDailyRows(orders, expenses, cashFloat, tag, yearMonth, posConfig)) },
    { name: `${t}-備料明細表(月報).csv`, buf: c(buildPrepRows(prepCounts, prepItems, tag, yearMonth)) },
    { name: `${t}-支出明細表(月報).csv`, buf: c(buildExpenseRows(expenses, posConfig)) },
    { name: `${t}-結算摘要(月報).json`, buf: j(buildSummary(orders, cashFloat, tag, yearMonth)) },
  ]
}

/**
 * 幫「某一攤」結一個月的報表並上傳。
 * @param ctx 跟 runBackup 一樣的 ctx，額外用得到 ctx.scopeOf（支援 bizDate 版本）
 */
async function runMonthlyBackup(ctx, { projectId, yearMonth }) {
  const { dataDir } = ctx
  const cfg = loadConfig(dataDir)
  if (!cfg.refreshToken) throw new Error('尚未完成 Google 雲端授權')

  const posConfig = ctx.readConfig()
  const sel = selectorFor(projectId, posConfig)
  const { from, to } = monthRangeOf(yearMonth)
  const all = ctx.readOrders()
  const orders = all.filter(o => o.bizDate >= from && o.bizDate <= to && sel.match(o))
  const expenses = (posConfig?.expenses ?? []).filter(e => e.date >= from && e.date <= to && sel.match(e))
  const prepCounts = (posConfig?.prepCounts ?? []).filter(c => c.bizDate >= from && c.bizDate <= to && sel.match(c))
  const prepItems = posConfig?.prepItems ?? []
  const projectName = sel.tag
  const cashFloat = monthCashFloat(projectId, from, to, posConfig)

  const scope = ctx.scopeOf
    ? ctx.scopeOf(projectId, posConfig, from)
    : { kind: '店面', name: projectName, year: yearMonth.slice(0, 4), month: yearMonth.slice(5, 7) }
  const segs = [scope.kind, scope.name, scope.year, scope.month].map(sanitizeSeg)

  const files = buildMonthlyBundle(projectName, orders, expenses, cashFloat, prepCounts, prepItems, posConfig, yearMonth)

  // 跟日結一樣：先寫本地暫存，全部確認上傳成功才刪
  const stageDir = path.join(dataDir, 'backup-monthly', ...segs, yearMonth)
  fs.mkdirSync(stageDir, { recursive: true })
  for (const f of files) fs.writeFileSync(path.join(stageDir, f.name), f.buf)

  const log = loadMonthlyLog(dataDir)
  const run = {
    at: Date.now(), projectId, projectName, yearMonth,
    orders: orders.length, bytes: files.reduce((a, f) => a + f.buf.length, 0),
    ok: false, files: [], error: null,
  }
  try {
    const token = await gdrive.accessToken(cfg)
    const folderid = await gdrive.ensureFolderPath(token, [cfg.rootFolder, ...segs])
    for (const f of files) {
      const r = await gdrive.uploadFile(token, folderid, f.name, f.buf)
      if (Number(r.size) !== f.buf.length) {
        throw new Error(`${f.name} 上傳後大小不符（雲端 ${r.size} / 本地 ${f.buf.length}），已中止，本地檔案保留`)
      }
      run.files.push({ name: f.name, size: r.size, fileid: r.fileid })
    }
    run.ok = true
    if (cfg.deleteLocalAfterUpload) {
      fs.rmSync(stageDir, { recursive: true, force: true })
      run.stageDeleted = true
    }
  } catch (e) {
    run.error = e.message
  }
  log.runs.push(run)
  saveMonthlyLog(dataDir, log)
  return run
}

/**
 * 每天檢查一次：如果現在是月初前幾天，而且「上個月」還沒結過月報，就替每一攤結一次。
 * 沒有資料的攤位（那個月根本沒營業）直接跳過，不浪費一次上傳。
 * 全部結完（或全部都是「本來就沒資料」）才把這個月標記完成——
 * 只要有一攤失敗，下次檢查還是會整個月重跑一次，不會漏掉那一攤。
 */
async function checkAndRunMonthlyBackups(ctx, { force = false, forceMonth = null } = {}) {
  const { dataDir } = ctx
  const cfg = loadConfig(dataDir)
  if (!cfg.refreshToken) return { skipped: 'not_authed' }
  if (!force && !isMonthStartWindow(5)) return { skipped: 'not_month_start' }

  const yearMonth = forceMonth || prevMonthOf()
  const log = loadMonthlyLog(dataDir)
  if (!force && (log.doneMonths ?? []).includes(yearMonth)) return { skipped: 'already_done', yearMonth }

  const posConfig = ctx.readConfig()
  const { from, to } = monthRangeOf(yearMonth)
  const allOrders = ctx.readOrders()

  const scopeIds = ['all', 'default',
    ...(posConfig?.branches ?? []).map(b => 'branch:' + b.id),
    ...(posConfig?.projects ?? []).filter(p => monthOverlaps(p, yearMonth)).map(p => p.id),
  ]

  const results = []
  for (const projectId of scopeIds) {
    const sel = selectorFor(projectId, posConfig)
    const hasOrders = allOrders.some(o => o.bizDate >= from && o.bizDate <= to && sel.match(o))
    const hasExpenses = (posConfig?.expenses ?? []).some(e => e.date >= from && e.date <= to && sel.match(e))
    const hasPrep = (posConfig?.prepCounts ?? []).some(c => c.bizDate >= from && c.bizDate <= to && sel.match(c))
    if (!hasOrders && !hasExpenses && !hasPrep) {
      results.push({ projectId, yearMonth, ok: true, skippedEmpty: true })
      continue
    }
    try { results.push(await runMonthlyBackup(ctx, { projectId, yearMonth })) }
    catch (e) { results.push({ projectId, yearMonth, ok: false, error: e.message }) }
  }

  const allOk = results.every(r => r.ok)
  if (allOk) {
    log.doneMonths = [...(log.doneMonths ?? []), yearMonth]
    saveMonthlyLog(dataDir, log)
  }
  return { yearMonth, results, allOk }
}

function monthlyStatus(dataDir) {
  const log = loadMonthlyLog(dataDir)
  const runs = [...(log.runs ?? [])].reverse()
  return {
    doneMonths: [...(log.doneMonths ?? [])].sort(),
    lastOk: runs.find(r => r.ok) ?? null,
    lastRun: runs[0] ?? null,
    recent: runs.slice(0, 20),
  }
}

module.exports = {
  loadConfig, saveConfig, publicConfig,
  runBackup, retryPending, pruneOrders, status,
  buildCsv, buildSummary, buildBundle, selectorFor,
  buildDailyRows, buildProductRows, buildExpenseRows,
  buildPnlRows, buildTaRows, buildPrepRows, buildMonthlyBundle,
  runMonthlyBackup, checkAndRunMonthlyBackups, monthlyStatus,
  monthRangeOf, prevMonthOf, monthOverlaps, isMonthStartWindow,
}
