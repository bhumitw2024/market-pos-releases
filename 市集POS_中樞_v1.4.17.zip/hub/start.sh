#!/data/data/com.termux/files/usr/bin/bash
# 三星手機（Termux）啟動腳本
# 用法：bash start.sh

cd "$(dirname "$0")" || exit 1

# 保持 CPU 喚醒，避免手機休眠時把中樞砍掉
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock

if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  找不到 Node.js，請先執行："
  echo "      pkg update -y && pkg install -y nodejs-lts"
  echo ""
  exit 1
fi

while true; do
  node hub.js
  code=$?
  if [ "$code" -eq 75 ]; then
    echo ""
    echo "  偵測到更新，3 秒後自動重新啟動中樞…"
    echo ""
    sleep 3
    continue
  fi
  exit "$code"
done
