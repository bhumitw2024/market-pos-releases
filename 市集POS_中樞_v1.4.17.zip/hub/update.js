/**
 * 檢查更新／一鍵更新
 * ============================================================
 * 賣出去之後，要怎麼把新版推給客戶？
 *
 * 這一套是「攤位中樞 ＋ iPad 開網頁」的架構，
 * 所有 iPad 的畫面都是中樞發出去的（www/ 那包）。
 * 所以**只要把中樞那一台更新掉，全部裝置就一起更新了** ——
 * 不用一台一台去裝，也不用上架 App Store 等審核。
 *
 * 做法：
 *   1. 中樞每天（或按下按鈕時）去一個「版本檔」網址看有沒有新版。
 *      版本檔就是一個 JSON，放在你自己的網站或 GitHub Release 上。
 *   2. 有新版就下載那包 zip，先驗證大小與（選填）SHA-256，
 *      再把現在的 www/ 與 *.js 備份成 backup-<版本>/，最後才覆蓋。
 *   3. 出問題可以一鍵還原上一版。
 *
 * 刻意的設計：
 *   · **資料完全不動**。data/ 目錄（訂單、設定、備份紀錄）永遠不碰。
 *   · **不自動安裝**。預設只通知，要不要更新由店家自己按 ——
 *     營業中被自動更新打斷是災難。
 *   · 沒有網路、版本檔壞掉、下載失敗，一律安靜跳過，中樞照常運作。
 */

const fs = require('fs')
const path = require('path')
const https = require('https')
const http = require('http')
const crypto = require('crypto')
const { execFileSync } = require('child_process')

const DEFAULT_CFG = {
  /** 版本檔網址。留空 = 關閉檢查更新 */
  manifestUrl: '',
  /** 自動檢查（一天一次）。安裝永遠要手動按 */
  autoCheck: true,
  /** 通道，讓你可以先發測試版給特定客戶 */
  channel: 'stable',
}

function cfgFile(dataDir) { return path.join(dataDir, 'update-config.json') }
function stateFile(dataDir) { return path.join(dataDir, 'update-state.json') }

function readJson(f, fallback) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')) } catch { return fallback }
}
function writeJson(f, obj) {
  const tmp = f + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2))
  fs.renameSync(tmp, f)
}

function loadConfig(dataDir) { return { ...DEFAULT_CFG, ...readJson(cfgFile(dataDir), {}) } }
function saveConfig(dataDir, patch) {
  const next = { ...loadConfig(dataDir), ...patch }
  writeJson(cfgFile(dataDir), next)
  return next
}
function loadState(dataDir) {
  return readJson(stateFile(dataDir), { lastCheck: 0, latest: null, history: [] })
}
function saveState(dataDir, patch) {
  const next = { ...loadState(dataDir), ...patch }
  next.history = (next.history ?? []).slice(-20)
  writeJson(stateFile(dataDir), next)
  return next
}

// ---------------------------------------------------------------- 版本比較

/** 1.10.0 要大於 1.9.0 —— 直接字串比會反過來，所以照數字一段一段比 */
function cmpVersion(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10) || 0)
  const pb = String(b).split('.').map(n => parseInt(n, 10) || 0)
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0)
    if (d) return d > 0 ? 1 : -1
  }
  return 0
}

function get(url, { redirects = 5 } = {}) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https:') ? https : http
    const req = lib.get(url, { timeout: 20000, headers: { 'User-Agent': 'market-pos-hub' } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects > 0) {
        res.resume()
        return resolve(get(new URL(res.headers.location, url).toString(), { redirects: redirects - 1 }))
      }
      if (res.statusCode !== 200) {
        res.resume()
        return reject(new Error(`下載失敗 HTTP ${res.statusCode}`))
      }
      const chunks = []
      res.on('data', c => chunks.push(c))
      res.on('end', () => resolve(Buffer.concat(chunks)))
    })
    req.on('timeout', () => { req.destroy(new Error('連線逾時')) })
    req.on('error', reject)
  })
}

/**
 * 版本檔長這樣（放在你自己的網站或 GitHub Release）：
 * {
 *   "stable": {
 *     "version": "1.2.0",
 *     "url": "https://example.com/market-pos-hub-1.2.0.zip",
 *     "sha256": "…（選填，強烈建議填）",
 *     "size": 1234567,
 *     "notes": "修正 …",
 *     "date": "2026-09-01",
 *     "minNode": "18"
 *   }
 * }
 */
async function check(dataDir, currentVersion) {
  const cfg = loadConfig(dataDir)
  if (!cfg.manifestUrl) {
    return { ok: false, reason: '尚未設定版本檔網址', current: currentVersion, hasUpdate: false }
  }
  try {
    const buf = await get(cfg.manifestUrl)
    const manifest = JSON.parse(buf.toString('utf8'))
    const rel = manifest[cfg.channel] ?? manifest.stable ?? manifest
    if (!rel || !rel.version) throw new Error('版本檔格式不對（缺 version）')

    const hasUpdate = cmpVersion(rel.version, currentVersion) > 0
    saveState(dataDir, { lastCheck: Date.now(), latest: rel })
    return { ok: true, current: currentVersion, latest: rel, hasUpdate }
  } catch (e) {
    saveState(dataDir, { lastCheck: Date.now(), lastError: e.message })
    return { ok: false, reason: e.message, current: currentVersion, hasUpdate: false }
  }
}

// ---------------------------------------------------------------- 安裝

function hasUnzip() {
  try {
    execFileSync(process.platform === 'win32' ? 'powershell' : 'unzip',
      process.platform === 'win32' ? ['-Command', 'exit 0'] : ['-v'],
      { stdio: 'ignore' })
    return true
  } catch { return false }
}

function unzip(zipPath, destDir) {
  fs.mkdirSync(destDir, { recursive: true })
  if (process.platform === 'win32') {
    execFileSync('powershell', ['-NoProfile', '-Command',
      `Expand-Archive -Force -LiteralPath "${zipPath}" -DestinationPath "${destDir}"`],
      { stdio: 'ignore' })
  } else {
    execFileSync('unzip', ['-o', '-q', zipPath, '-d', destDir], { stdio: 'ignore' })
  }
}

/** 更新只換程式，data/ 一律不碰 */
/**
 * 更新時**不能碰**的東西。除了這些，新版包裡有什麼就換什麼。
 * ------------------------------------------------------------
 * 早期版本是寫死一份「要換哪幾個檔」的清單，結果每次新增模組
 * （例如 pay.js、invoice.js）都得記得回來加一行 —— 漏掉的話，
 * 客戶更新完會拿到「新的 hub.js 配舊的模組」，直接開不起來。
 * 改成反過來列「不要動的」，新增檔案就不用再改這裡。
 */
const KEEP = new Set([
  'data',              // 訂單、金鑰、設定 —— 更新永遠不碰
  'node_modules',      // 理論上用不到（零依賴），保險起見
])

/** 這一包新版裡，哪些東西要覆蓋過去 */
function replaceList(srcDir) {
  return fs.readdirSync(srcDir).filter(name => !KEEP.has(name))
}

/**
 * 下載並安裝。回傳 { ok, version, backupDir, needRestart }
 * 失敗時什麼都不會動到（先下載驗證，全部 OK 才覆蓋）。
 */
async function install(dataDir, rootDir, currentVersion) {
  const st = loadState(dataDir)
  const rel = st.latest
  if (!rel?.url) throw new Error('沒有可安裝的版本，請先按「檢查更新」')
  if (cmpVersion(rel.version, currentVersion) <= 0) throw new Error(`目前已經是 ${currentVersion}，不需要更新`)

  const tmpDir = path.join(dataDir, 'update-tmp')
  fs.rmSync(tmpDir, { recursive: true, force: true })
  fs.mkdirSync(tmpDir, { recursive: true })

  // 1. 下載
  const buf = await get(rel.url)
  if (rel.size && Number(rel.size) !== buf.length) {
    throw new Error(`下載大小不符（預期 ${rel.size} / 實際 ${buf.length}），已中止，什麼都沒動`)
  }
  if (rel.sha256) {
    const got = crypto.createHash('sha256').update(buf).digest('hex')
    if (got.toLowerCase() !== String(rel.sha256).toLowerCase()) {
      throw new Error('檔案校驗碼不符，可能被竄改或下載不完整，已中止，什麼都沒動')
    }
  }

  const zipPath = path.join(tmpDir, 'update.zip')
  fs.writeFileSync(zipPath, buf)

  // 2. 解壓縮到暫存，確認裡面真的有東西才繼續
  const exDir = path.join(tmpDir, 'x')
  unzip(zipPath, exDir)
  let srcDir = exDir
  const inner = fs.readdirSync(exDir, { withFileTypes: true })
  // zip 裡如果只包了一層資料夾（hub/），自動往下鑽一層
  if (inner.length === 1 && inner[0].isDirectory()) srcDir = path.join(exDir, inner[0].name)
  if (!fs.existsSync(path.join(srcDir, 'hub.js'))) {
    throw new Error('更新檔裡找不到 hub.js，格式不對，已中止，什麼都沒動')
  }

  const REPLACE = replaceList(srcDir)

  // 3. 備份現在這一版（只備份程式，data/ 不動）
  const backupDir = path.join(dataDir, 'backup-version', `${currentVersion}-${Date.now()}`)
  fs.mkdirSync(backupDir, { recursive: true })
  for (const name of REPLACE) {
    const from = path.join(rootDir, name)
    if (fs.existsSync(from)) fs.cpSync(from, path.join(backupDir, name), { recursive: true })
  }

  // 4. 覆蓋
  for (const name of REPLACE) {
    const from = path.join(srcDir, name)
    if (!fs.existsSync(from)) continue
    const to = path.join(rootDir, name)
    fs.rmSync(to, { recursive: true, force: true })
    fs.cpSync(from, to, { recursive: true })
  }

  fs.rmSync(tmpDir, { recursive: true, force: true })

  const entry = {
    at: Date.now(), from: currentVersion, to: rel.version,
    notes: rel.notes ?? '', backupDir,
  }
  const state = loadState(dataDir)
  saveState(dataDir, { history: [...(state.history ?? []), entry], installed: entry })

  return { ok: true, version: rel.version, backupDir, needRestart: true, notes: rel.notes ?? '' }
}

/** 還原上一版（更新之後發現有問題時用） */
function rollback(dataDir, rootDir) {
  const st = loadState(dataDir)
  const last = [...(st.history ?? [])].reverse()[0]
  if (!last?.backupDir || !fs.existsSync(last.backupDir)) throw new Error('找不到可還原的備份')
  // 還原的來源是「上一版的備份資料夾」，所以要換的就是那裡面有的東西
  for (const name of replaceList(last.backupDir)) {
    const from = path.join(last.backupDir, name)
    if (!fs.existsSync(from)) continue
    const to = path.join(rootDir, name)
    fs.rmSync(to, { recursive: true, force: true })
    fs.cpSync(from, to, { recursive: true })
  }
  saveState(dataDir, { rolledBackTo: last.from, rolledBackAt: Date.now() })
  return { ok: true, version: last.from, needRestart: true }
}

function status(dataDir, currentVersion) {
  const st = loadState(dataDir)
  return {
    current: currentVersion,
    config: loadConfig(dataDir),
    lastCheck: st.lastCheck ?? 0,
    lastError: st.lastError ?? null,
    latest: st.latest ?? null,
    hasUpdate: Boolean(st.latest?.version && cmpVersion(st.latest.version, currentVersion) > 0),
    history: st.history ?? [],
    canUnzip: hasUnzip(),
  }
}

module.exports = {
  loadConfig, saveConfig, status, check, install, rollback, cmpVersion,
}
