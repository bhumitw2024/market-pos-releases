/**
 * 電子發票 ── 通用串接（跑在中樞這一台）
 * ============================================================
 * 客戶用哪一家電子發票平台，我們不知道也不該綁死：
 * 綠界、藍新、財政部大平台、加值中心自架的 API…
 * 欄位名稱、簽章方式、端點通通不一樣。
 *
 * 所以這裡不「支援某一家」，而是做成**可設定的轉接層**：
 *
 *   1. 端點網址        ← 照平台文件填
 *   2. 請求範本（JSON）← 照平台文件填欄位名稱，值用 {{變數}} 代入
 *   3. 簽章方式        ← none / md5 / sha256 / hmac-sha256，串接字串也是範本
 *   4. 金鑰            ← HashKey / HashIV / 商店代號，**只存在中樞**
 *
 * 可以用的變數：
 *   {{orderId}} {{serial}} {{bizDate}} {{time}} {{timestamp}}
 *   {{amount}} {{taxAmount}} {{salesAmount}} {{itemCount}}
 *   {{itemNames}} {{itemCounts}} {{itemPrices}} {{itemAmounts}}
 *   {{buyerTaxId}} {{carrierId}} {{carrierType}} {{merchantId}} {{sellerTaxId}}
 *   {{hashKey}} {{hashIv}}（只允許出現在「簽章字串範本」裡，不會進 log）
 *
 * 為什麼要這樣做：白牌賣給十家店，就會遇到十種平台。
 * 每遇到一家就改一次程式碼，等於每一家都要重新出貨、重新測試；
 * 做成設定之後，現場的人照著文件填一次表單就通了。
 *
 * 資安：HashKey／HashIV 與商店代號**只寫在中樞的 data/invoice.json**，
 * 對外的 API 一律遮蔽成「已設定」，前端與自助下單頁永遠拿不到。
 */

const fs = require('fs')
const path = require('path')
const crypto = require('crypto')

function file(dataDir) { return path.join(dataDir, 'invoice.json') }

function readJson(f, fallback) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')) } catch { return fallback }
}
function writeJsonAtomic(f, obj) {
  const tmp = f + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2), { mode: 0o600 })
  fs.renameSync(tmp, f)
}

const DEFAULTS = {
  enabled: false,
  /** 只是給人看的名字，例如「綠界」「藍新」「XX 加值中心」 */
  provider: '',
  endpoint: '',
  voidEndpoint: '',
  method: 'POST',
  contentType: 'application/json',
  merchantId: '',
  hashKey: '',
  hashIv: '',
  sellerTaxId: '',
  sandbox: true,
  taxRate: 5,
  /** 請求本文範本（JSON 字串，值用 {{變數}}） */
  bodyTemplate: '',
  /** 額外的 HTTP 標頭（物件） */
  headers: {},
  /** 簽章：none | md5 | sha256 | hmac-sha256 */
  signAlgo: 'none',
  /** 要簽的字串範本，例如 HashKey={{hashKey}}&...&HashIV={{hashIv}} */
  signTemplate: '',
  /** 算出來的簽章要放進本文的哪一個欄位名 */
  signField: 'CheckMacValue',
  /** 判斷成功的欄位與值，例如 RtnCode = 1 */
  successField: '',
  successValue: '',
  /** 發票號碼在回應裡的欄位名 */
  numberField: '',
}

function loadConfig(dataDir) {
  return { ...DEFAULTS, ...readJson(file(dataDir), {}) }
}

function saveConfig(dataDir, patch) {
  const next = { ...loadConfig(dataDir), ...patch }
  writeJsonAtomic(file(dataDir), next)
  return publicConfig(dataDir)
}

/** 給前端看的版本：金鑰只回報有沒有設定 */
function publicConfig(dataDir) {
  const c = loadConfig(dataDir)
  const { hashKey, hashIv, ...rest } = c
  return {
    ...rest,
    hashKey: hashKey ? '已設定' : '',
    hashIv: hashIv ? '已設定' : '',
    hasKeys: Boolean(hashKey),
    ready: Boolean(c.enabled && c.endpoint && c.bodyTemplate),
  }
}

// ---------------------------------------------------------------- 範本

function varsOf(cfg, order) {
  const items = order.items ?? []
  const amount = Math.round(order.total ?? 0)
  const rate = Number(cfg.taxRate ?? 5)
  // 台灣的含稅單價回推：銷售額 = 含稅 / (1+稅率)，稅額 = 含稅 − 銷售額
  const sales = Math.round(amount / (1 + rate / 100))
  const d = new Date(order.createdAt ?? Date.now())
  const pad = n => String(n).padStart(2, '0')
  return {
    orderId: order.id ?? '',
    serial: order.serialText ?? '',
    bizDate: order.bizDate ?? '',
    time: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`,
    timestamp: String(Math.floor((order.createdAt ?? Date.now()) / 1000)),
    amount: String(amount),
    salesAmount: String(sales),
    taxAmount: String(amount - sales),
    itemCount: String(items.length),
    itemNames: items.map(i => i.productName).join('|'),
    itemCounts: items.map(i => i.qty).join('|'),
    itemPrices: items.map(i => i.unitPrice).join('|'),
    itemAmounts: items.map(i => i.unitPrice * i.qty).join('|'),
    buyerTaxId: order.invoice?.buyerTaxId ?? '',
    carrierId: order.invoice?.carrierId ?? '',
    carrierType: order.invoice?.carrierType ?? '',
    merchantId: cfg.merchantId ?? '',
    sellerTaxId: cfg.sellerTaxId ?? '',
    hashKey: cfg.hashKey ?? '',
    hashIv: cfg.hashIv ?? '',
  }
}

function fill(template, vars) {
  return String(template ?? '').replace(/\{\{(\w+)\}\}/g, (_, k) => (k in vars ? String(vars[k]) : ''))
}

function signature(algo, text, key) {
  if (algo === 'md5') return crypto.createHash('md5').update(text).digest('hex').toUpperCase()
  if (algo === 'sha256') return crypto.createHash('sha256').update(text).digest('hex').toUpperCase()
  if (algo === 'hmac-sha256') return crypto.createHmac('sha256', key || '').update(text).digest('base64')
  return ''
}

/**
 * 組出真正要送出去的東西。
 * 這個函式故意跟「送出」分開 —— 設定頁的「試算」就是呼叫它而已，
 * 讓人在真的開發票之前，先看清楚會送出什麼欄位。
 */
function buildRequest(cfg, order) {
  const vars = varsOf(cfg, order)
  const raw = fill(cfg.bodyTemplate, vars)
  let body
  try { body = JSON.parse(raw || '{}') }
  catch (e) { throw new Error('請求範本填完之後不是合法的 JSON：' + e.message) }

  if (cfg.signAlgo && cfg.signAlgo !== 'none') {
    const text = fill(cfg.signTemplate, vars)
    body[cfg.signField || 'CheckMacValue'] = signature(cfg.signAlgo, text, cfg.hashKey)
  }
  return { url: cfg.endpoint, method: cfg.method || 'POST', headers: cfg.headers ?? {}, body }
}

/** 把金鑰換成 ••••，可以安心顯示在畫面上或寫進 log */
function maskRequest(cfg, req) {
  const text = JSON.stringify(req)
  let out = text
  for (const secret of [cfg.hashKey, cfg.hashIv].filter(Boolean)) {
    out = out.split(secret).join('••••••')
  }
  return JSON.parse(out)
}

function post(url, method, headers, contentType, bodyStr, timeoutMs = 15000) {
  const u = new URL(url)
  const mod = u.protocol === 'http:' ? require('http') : require('https')
  return new Promise((resolve, reject) => {
    const req = mod.request({
      hostname: u.hostname,
      port: u.port || (u.protocol === 'http:' ? 80 : 443),
      path: u.pathname + u.search,
      method,
      headers: {
        'Content-Type': contentType,
        'Content-Length': Buffer.byteLength(bodyStr),
        ...headers,
      },
      timeout: timeoutMs,
    }, res => {
      const chunks = []
      res.on('data', c => chunks.push(c))
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8')
        let json = null
        try { json = JSON.parse(text) } catch { /* 有些平台回 form-urlencoded */ }
        resolve({ status: res.statusCode, text, json })
      })
    })
    req.on('timeout', () => req.destroy(new Error('連線逾時')))
    req.on('error', reject)
    req.end(bodyStr)
  })
}

async function issue(dataDir, order) {
  const cfg = loadConfig(dataDir)
  if (!cfg.enabled) return { ok: false, reason: 'disabled', message: '電子發票尚未啟用' }
  if (!cfg.endpoint || !cfg.bodyTemplate) {
    return { ok: false, reason: 'not_configured', message: '還沒設定端點或請求範本' }
  }

  let req
  try { req = buildRequest(cfg, order) }
  catch (e) { return { ok: false, reason: 'template', message: e.message } }

  const bodyStr = cfg.contentType === 'application/json'
    ? JSON.stringify(req.body)
    : new URLSearchParams(req.body).toString()

  let res
  try {
    res = await post(req.url, req.method, req.headers, cfg.contentType, bodyStr)
  } catch (e) {
    return { ok: false, reason: 'network', message: e.message, sent: maskRequest(cfg, req) }
  }

  const data = res.json ?? {}
  const ok = cfg.successField
    ? String(data[cfg.successField] ?? '') === String(cfg.successValue ?? '')
    : res.status >= 200 && res.status < 300
  return {
    ok,
    status: res.status,
    number: cfg.numberField ? (data[cfg.numberField] ?? '') : '',
    response: res.json ?? res.text.slice(0, 500),
    sent: maskRequest(cfg, req),
  }
}

/** 試算：只組不送，讓人先看清楚會送出什麼 */
function dryRun(dataDir, order) {
  const cfg = loadConfig(dataDir)
  try {
    const req = buildRequest(cfg, order)
    return { ok: true, sent: maskRequest(cfg, req), endpoint: cfg.endpoint || '(還沒填端點)' }
  } catch (e) {
    return { ok: false, message: e.message }
  }
}

module.exports = { loadConfig, saveConfig, publicConfig, issue, dryRun, buildRequest, fill, signature }
