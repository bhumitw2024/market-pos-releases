// 自動產生，請勿手動修改 —— 由 node tools/gen-sw.mjs 產生
// 離線 App Shell 快取：讓網頁本身（不只是訂單資料）也能在完全沒有網路時打開
const CACHE_NAME = "market-pos-shell-2cbf474fb308"
const CORE_ASSETS = ["/","/assets/index-CiytPCg-.js","/assets/index-MN8_eQ8U.css","/index.html"]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE_ASSETS))
      .then(() => self.skipWaiting())
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  )
})

self.addEventListener('fetch', (event) => {
  const req = event.request
  if (req.method !== 'GET') return

  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return // 跨網域（Supabase、字型等）不經手
  if (url.pathname.startsWith('/api/')) return // 中樞 API 一律直連，斷線就讓它照原本的方式失敗/走本機備援

  if (req.mode === 'navigate') {
    // 網頁本身：先連中樞拿最新的，連不到才用快取，避免卡在舊版畫面
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', copy)).catch(() => {})
          return res
        })
        .catch(() => caches.match('/index.html').then((r) => r || caches.match('/')))
    )
    return
  }

  // 其他同網域檔案（JS/CSS 等，檔名帶內容雜湊，內容不會變）：
  // 快取有就直接用，不額外背景重新驗證 —— 檔名帶雜湊代表「同一個網址＝同一份內容」，
  // 重新驗證沒有意義，反而會在離線時多一個註定失敗、可能干擾畫面的背景連線
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached
      return fetch(req).then((res) => {
        if (res && res.ok) {
          const copy = res.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {})
        }
        return res
      })
    })
  )
})
