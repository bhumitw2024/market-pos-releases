/**
 * 自簽 HTTPS 憑證產生器（零依賴，純 Node.js crypto）
 * ============================================================
 * 為什麼要自己生：中樞是私有 IP（例如 192.168.43.1），不是網域名稱，
 * 沒有任何公開憑證機構（CA）會發憑證給一個私有 IP —— 這種情況全世界的做法
 * 都是「自簽憑證」：自己當自己的 CA，裝置第一次連線時瀏覽器會跳警告，
 * 使用者手動按一次「繼續前往」，之後同一個裝置再連就不會一直跳。
 *
 * 為什麼要自己手刻 X.509 DER 編碼，不裝 npm 套件：這支專案刻意保持
 * 「零依賴，只用 Node.js 內建模組」，換裝置（Termux／Windows）都不用另外裝東西、
 * 不用擔心套件版本問題。Node 本身沒有內建「產生憑證」的高階 API，
 * 但 `crypto.generateKeyPairSync` 能生金鑰、`crypto.sign` 能簽章，
 * 缺的只是把這些組成一張合法憑證的 DER/ASN.1 編碼，這裡就是在做這件事。
 *
 * 只用得到 RSA + sha256WithRSAEncryption 這一種演算法組合，
 * 這是相容性最廣、簽章編碼也最單純（RSA 簽章就是原始位元組，不像 ECDSA
 * 還要另外包一層 SEQUENCE{r,s}）的選擇，換來程式碼簡單很多。
 */

const crypto = require('crypto')
const fs = require('fs')
const path = require('path')

// ---------------------------------------------------------------- DER 編碼小工具

function derLen(n) {
  if (n < 0x80) return Buffer.from([n])
  const bytes = []
  let v = n
  while (v > 0) { bytes.unshift(v & 0xff); v >>= 8 }
  return Buffer.from([0x80 | bytes.length, ...bytes])
}

function tlv(tag, content) {
  return Buffer.concat([Buffer.from([tag]), derLen(content.length), content])
}

function derSeq(...parts) { return tlv(0x30, Buffer.concat(parts)) }
function derSet(...parts) { return tlv(0x31, Buffer.concat(parts)) }

/** INTEGER：正數且最高位元是 1 的話要補一個 0x00，不然會被讀成負數 */
function derInt(buf) {
  let b = buf
  while (b.length > 1 && b[0] === 0x00 && (b[1] & 0x80) === 0) b = b.subarray(1)
  if (b[0] & 0x80) b = Buffer.concat([Buffer.from([0x00]), b])
  return tlv(0x02, b)
}
function derIntFromNumber(n) {
  const bytes = []
  let v = n
  if (v === 0) bytes.push(0)
  while (v > 0) { bytes.unshift(v & 0xff); v = Math.floor(v / 256) }
  return derInt(Buffer.from(bytes))
}

function derOid(dotted) {
  const parts = dotted.split('.').map(Number)
  const out = [parts[0] * 40 + parts[1]]
  for (const p of parts.slice(2)) {
    if (p < 128) { out.push(p); continue }
    const chunk = []
    let v = p
    chunk.unshift(v & 0x7f)
    v >>= 7
    while (v > 0) { chunk.unshift((v & 0x7f) | 0x80); v >>= 7 }
    out.push(...chunk)
  }
  return tlv(0x06, Buffer.from(out))
}

function derNull() { return Buffer.from([0x05, 0x00]) }
function derBool(b) { return tlv(0x01, Buffer.from([b ? 0xff : 0x00])) }
function derOctetString(buf) { return tlv(0x04, buf) }
function derIA5String(str) { return tlv(0x16, Buffer.from(str, 'ascii')) }
function derPrintableString(str) { return tlv(0x13, Buffer.from(str, 'ascii')) }
function derUtf8String(str) { return tlv(0x0c, Buffer.from(str, 'utf8')) }

/** BIT STRING：位元組對齊的資料，第一個位元組（未使用位元數）固定填 0 */
function derBitString(buf) { return tlv(0x03, Buffer.concat([Buffer.from([0x00]), buf])) }

/** [n] EXPLICIT：外面再包一層 context-specific 建構型標籤 */
function explicitTag(n, content) { return tlv(0xa0 | n, content) }

/** [n] IMPLICIT，primitive：GeneralName 裡的 dNSName([2])／iPAddress([7]) 用這個 */
function implicitPrimitive(n, content) { return tlv(0x80 | n, content) }

function utcTime(date) {
  const p2 = n => String(n).padStart(2, '0')
  const yy = p2(date.getUTCFullYear() % 100)
  const mm = p2(date.getUTCMonth() + 1)
  const dd = p2(date.getUTCDate())
  const hh = p2(date.getUTCHours())
  const mi = p2(date.getUTCMinutes())
  const ss = p2(date.getUTCSeconds())
  return tlv(0x17, Buffer.from(`${yy}${mm}${dd}${hh}${mi}${ss}Z`, 'ascii'))
}

function ipv4ToBytes(ip) {
  const parts = ip.split('.').map(Number)
  if (parts.length !== 4 || parts.some(n => Number.isNaN(n) || n < 0 || n > 255)) return null
  return Buffer.from(parts)
}

// ---------------------------------------------------------------- 憑證組裝

const OID_COMMON_NAME = '2.5.4.3'
const OID_SHA256_RSA = '1.2.840.113549.1.1.11'
const OID_BASIC_CONSTRAINTS = '2.5.29.19'
const OID_SUBJECT_ALT_NAME = '2.5.29.17'

function nameOf(cn) {
  // Name ::= RDNSequence ::= SEQUENCE OF RelativeDistinguishedName(SET OF AttributeTypeAndValue)
  const atv = derSeq(derOid(OID_COMMON_NAME), derUtf8String(cn))
  return derSeq(derSet(atv))
}

function subjectAltNameExtValue(ips, dnsNames) {
  const generalNames = []
  for (const name of dnsNames) generalNames.push(implicitPrimitive(2, Buffer.from(name, 'ascii')))
  for (const ip of ips) {
    const b = ipv4ToBytes(ip)
    if (b) generalNames.push(implicitPrimitive(7, b))
  }
  return derSeq(...generalNames)
}

/**
 * 產生一張自簽憑證。回傳 PEM 格式的 { certPem, keyPem, sans }。
 * ips / dnsNames：要放進 SAN（Subject Alternative Name）的清單 ——
 * 現代瀏覽器只認 SAN，不會回頭看 CN，這裡沒放到的位址連上去一樣會被判定不符。
 */
function generate(ips, dnsNames = ['localhost']) {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 })
  const spki = publicKey.export({ type: 'spki', format: 'der' })

  const now = new Date()
  const notBefore = new Date(now.getTime() - 24 * 60 * 60 * 1000) // 提早一天生效，避免裝置時鐘誤差擋掉
  const notAfter = new Date(now.getTime() + 10 * 365 * 24 * 60 * 60 * 1000) // 10 年，不用常常換

  const subjectName = nameOf('MarketPOS-Hub')
  const sigAlg = derSeq(derOid(OID_SHA256_RSA), derNull())

  const basicConstraintsExt = derSeq(
    derOid(OID_BASIC_CONSTRAINTS),
    derBool(true), // critical
    derOctetString(derSeq()), // cA: FALSE（省略＝預設值）
  )
  const sanExt = derSeq(
    derOid(OID_SUBJECT_ALT_NAME),
    derOctetString(subjectAltNameExtValue(ips, dnsNames)),
  )
  const extensions = explicitTag(3, derSeq(basicConstraintsExt, sanExt))

  const serialNumber = derInt(crypto.randomBytes(16))

  const tbs = derSeq(
    explicitTag(0, derIntFromNumber(2)), // version v3
    serialNumber,
    sigAlg,
    subjectName, // issuer
    derSeq(utcTime(notBefore), utcTime(notAfter)), // validity
    subjectName, // subject（自簽：跟 issuer 一樣）
    spki,
    extensions,
  )

  const signature = crypto.sign('sha256', tbs, privateKey)
  const certDer = derSeq(tbs, sigAlg, derBitString(signature))

  const certPem = pem('CERTIFICATE', certDer)
  const keyPem = privateKey.export({ type: 'pkcs8', format: 'pem' })

  return { certPem, keyPem, sans: [...dnsNames, ...ips] }
}

function pem(label, der) {
  const b64 = der.toString('base64')
  const lines = b64.match(/.{1,64}/g) || []
  return `-----BEGIN ${label}-----\n${lines.join('\n')}\n-----END ${label}-----\n`
}

// ---------------------------------------------------------------- 讀取／快取

/**
 * 憑證只有在「沒有」或「目前的 IP 沒被涵蓋」時才會重新產生 ——
 * 重新產生代表每一台裝置都要重新按一次「繼續前往」的信任警告，
 * 能不換就不要換。中樞的 IP 通常是熱點固定配的，不太會變，
 * 真的變了（例如換了一台手機當中樞）這裡會自動偵測到並補發。
 */
function ensureCert(dataDir, currentIps) {
  const certPath = path.join(dataDir, 'https-cert.pem')
  const keyPath = path.join(dataDir, 'https-key.pem')

  const needIps = ['127.0.0.1', ...currentIps]

  if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
    try {
      const certPem = fs.readFileSync(certPath, 'utf8')
      const keyPem = fs.readFileSync(keyPath, 'utf8')
      const x509 = new crypto.X509Certificate(certPem)
      const covered = needIps.every(ip => x509.checkIP(ip))
      const stillValid = new Date(x509.validTo).getTime() > Date.now() + 24 * 60 * 60 * 1000
      if (covered && stillValid) return { certPem, keyPem, regenerated: false }
    } catch {
      // 檔案壞掉或讀不懂，當作沒有，往下重新產生一份
    }
  }

  const { certPem, keyPem } = generate(needIps)
  fs.writeFileSync(certPath, certPem, { mode: 0o600 })
  fs.writeFileSync(keyPath, keyPem, { mode: 0o600 })
  return { certPem, keyPem, regenerated: true }
}

module.exports = { generate, ensureCert }
