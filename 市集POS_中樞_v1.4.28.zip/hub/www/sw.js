// 自動產生，請勿手動修改 —— 由 node tools/gen-sw.mjs 產生
// 離線 App Shell 快取：讓網頁本身（不只是訂單資料）也能在完全沒有網路時打開
const CACHE_NAME = "market-pos-shell-d63c0eee770b"
const CORE_ASSETS = ["/","/assets/index-MN8_eQ8U.css","/assets/index-YrppHUK6.js","/index.html"]

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE_ASSETS))
      .then(() => self.skipWaiting())
  )
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  )
})

/**
 * 帶逾時的 fetch。
 * ------------------------------------------------------------
 * 這裡踩過一個很嚴重的坑，寫下來免得又改回去：
 *   「完全沒有網路」跟「連著網路、但連不到中樞那個位址」是兩種完全不同的失敗速度 ——
 *   前者瀏覽器幾乎立刻就知道「沒有路可以送出去」，fetch 很快失敗；
 *   後者（例如 iPad 連到別的 WiFi，中樞是一個私有 IP，現在這個網路根本連不到那個位址）
 *   TCP 連線會一直重試，可能要卡幾十秒才會真的失敗。
 *   沒加逾時的話，網頁重新整理／結帳這些動作在「連錯網路」時會卡住很久，
 *   使用者感覺起來比「完全沒有網路」還糟——反而是網路完全斷開的時候
 *   （瀏覽器立刻回報失敗）比較快退回本機模式。
 *   一律加一個合理短的逾時，讓「連不到中樞」不管是哪種原因都一樣快失敗。
 */
function fetchWithTimeout(req, ms) {
  const ctl = new AbortController()
  const t = setTimeout(() => ctl.abort(), ms)
  return fetch(req, { signal: ctl.signal }).finally(() => clearTimeout(t))
}

self.addEventListener('fetch', (event) => {
  const req = event.request
  if (req.method !== 'GET') return

  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return // 跨網域（Supabase、字型等）不經手
  if (url.pathname.startsWith('/api/')) return // 中樞 API 一律直連，斷線就讓它照原本的方式失敗/走本機備援

  if (req.mode === 'navigate') {
    // 網頁本身：先連中樞拿最新的，連不到（或連太久）才用快取，避免卡在舊版畫面，
    // 也避免「連錯網路」時整頁卡住半天打不開
    event.respondWith(
      fetchWithTimeout(req, 4000)
        .then((res) => {
          const copy = res.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put('/index.html', copy)).catch(() => {})
          return res
        })
        .catch(() => caches.match('/index.html').then((r) => r || caches.match('/')))
    )
    return
  }

  // 其他同網域檔案（JS/CSS 等，檔名帶內容雜湊，內容不會變）：
  // 快取有就直接用，不額外背景重新驗證 —— 檔名帶雜湊代表「同一個網址＝同一份內容」，
  // 重新驗證沒有意義，反而會在離線時多一個註定失敗、可能干擾畫面的背景連線。
  // 快取沒有才會真的連網路，一樣加逾時，避免「連錯網路」卡住。
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached
      return fetchWithTimeout(req, 4000).then((res) => {
        if (res && res.ok) {
          const copy = res.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put(req, copy)).catch(() => {})
        }
        return res
      })
    })
  )
})
