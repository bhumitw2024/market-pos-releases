#!/usr/bin/env node
/**
 * 市集 POS ── 攤位中樞 (Hub)
 * ============================================================
 * 零依賴，只用 Node.js 內建模組。同一支檔案可以跑在：
 *   · 三星手機（Termux）      → 市集現場用
 *   · Windows 電腦            → 店面或備援用
 *
 * 它做三件事：
 *   1. 把 POS 網頁發給同一個熱點下的任何裝置（iPad 用 Safari 開就好）
 *   2. 集中發號 —— 所有裝置共用一組流水號，永遠不會撞號
 *   3. 收到列印請求後，用 TCP 連到標籤機的 9100 埠送出 ESC/POS
 *
 * 第 3 點正是 iPad 瀏覽器做不到、必須由中樞代勞的那一段。
 *
 * 啟動：  node hub.js
 * 選項：  PORT=8080 PRINTER=192.168.43.100 node hub.js
 */

const http = require('http')
const https = require('https')
const certgen = require('./certgen')
const net = require('net')
const fs = require('fs')
const path = require('path')
const os = require('os')
const backup = require('./backup')
const gdrive = require('./gdrive')
const update = require('./update')
const pay = require('./pay')
const invoice = require('./invoice')

const ROOT = __dirname
const DATA_DIR = path.join(ROOT, 'data')
const PORT = Number(process.env.PORT || 8080)
const HTTPS_PORT = Number(process.env.HTTPS_PORT || 8443)
const VERSION = '1.4.28'

fs.mkdirSync(DATA_DIR, { recursive: true })

// ---------------------------------------------------------------- 儲存

const FILES = {
  config: path.join(DATA_DIR, 'config.json'),
  orders: path.join(DATA_DIR, 'orders.jsonl'),
  serials: path.join(DATA_DIR, 'serials.json'),
  /** 客人自助下單的暫存（還沒被攤位接單前都放這裡） */
  selfOrders: path.join(DATA_DIR, 'self-orders.json'),
  /** 遠端補印請求（要對方按同意才會印） */
  printReqs: path.join(DATA_DIR, 'print-requests.json'),
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return fallback }
}
function writeJsonAtomic(file, obj) {
  const tmp = file + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2))
  fs.renameSync(tmp, file)   // 原子性寫入：斷電也不會留下半個檔
}

let config = readJson(FILES.config, null)
let serials = readJson(FILES.serials, {})

/**
 * 一次性升級：舊版的計數 key 是「場次|營業日」，切場次號碼就會從 001 重來。
 * 這裡把同一個營業日的所有舊 key 併成一個，取最大值往下接。
 */
;(function migrateSerialKeys() {
  let changed = false
  for (const k of Object.keys(serials)) {
    if (!k.includes('|')) continue
    const bizDate = k.split('|').pop()
    serials[bizDate] = Math.max(serials[bizDate] || 0, serials[k] || 0)
    delete serials[k]
    changed = true
  }
  if (changed) writeJsonAtomic(FILES.serials, serials)
})()

/** 讀取全部訂單（jsonl 逐行，壞掉的行自動跳過，不會整包失效） */
function readOrders() {
  if (!fs.existsSync(FILES.orders)) return []
  const map = new Map()
  for (const line of fs.readFileSync(FILES.orders, 'utf8').split('\n')) {
    if (!line.trim()) continue
    try { const o = JSON.parse(line); map.set(o.id, o) } catch { /* 跳過壞行 */ }
  }
  return [...map.values()]
}
function appendOrder(order) {
  fs.appendFileSync(FILES.orders, JSON.stringify(order) + '\n')
}

// ---------------------------------------------------------------- 小型清單存放

/**
 * 自助下單與補印請求都是「短命的小清單」：
 * 幾十筆、幾小時內就處理掉。用一個 JSON 檔存最簡單，
 * 也不用擔心中樞跑在手機上被塞爆 —— 一律只留最近 300 筆。
 */
function listRead(file) { return readJson(file, []) }

function listUpsert(file, item) {
  const list = listRead(file)
  const i = list.findIndex(x => x.id === item.id)
  if (i >= 0) list[i] = { ...list[i], ...item }
  else list.unshift(item)
  writeJsonAtomic(file, list.slice(0, 300))
  return listRead(file).find(x => x.id === item.id)
}

/**
 * 給客人看的菜單（自助下單用）
 * ------------------------------------------------------------
 * **這裡是整個系統對外開放最寬的一個介面**（誰掃到 QR Code 都打得開），
 * 所以刻意只挑三樣東西送出去：品名、售價、選項。
 * 成本、毛利、密碼、金流金鑰、其他攤的營收 —— 一個字都不會出現在回應裡。
 */
function selfMenu(spot) {
  const c = config ?? {}

  /**
   * 「客人掃碼自助下單」開關（第十七輪回報第 2 項）
   * ------------------------------------------------------------
   * 以前這顆開關只是把後台設定頁那張卡收起來，客人手上的 /self 網址
   * 照樣打得開、單照樣送得出去——沒有真的擋到客人那一端，收攤想關掉
   * 自助下單其實關不掉。改成中樞直接檢查設定：關掉之後，不管客人是
   * 剛掃碼、還是本來就開著那個網頁（甚至回家後重新整理），要到菜單
   * 一律拿到「暫停中」，前端看到這個就會顯示「已暫停自助點餐」、
   * 不會讓客人送單（送單那支 API 這裡也會擋，見下面 POST /api/self/orders）。
   * 沒設定過（舊資料，selfOrderEnabled 是 undefined）視為開啟，跟以前一樣。
   */
  if (c.settings?.selfOrderEnabled === false) {
    return { disabled: true, brandName: c.settings?.brandName ?? '', updatedAt: c.updatedAt ?? 0 }
  }

  const branchId = spot.branchId || null
  const projectId = spot.projectId || null
  const hasEvent = Boolean(projectId) && projectId !== 'default'

  const availableHere = (avail) => {
    if (!avail || avail === 'all') return true
    const places = String(avail).startsWith('av:') ? avail.slice(3).split(';').filter(Boolean) : []
    if (!places.length) return true
    return places.some(k => {
      if (k === 'shops') return !hasEvent
      if (k === 'events') return hasEvent
      if (k.startsWith('branch:')) return (branchId || '__none__') === k.slice(7)
      if (k.startsWith('project:')) return hasEvent && projectId === k.slice(8)
      return false
    })
  }

  const priceHere = (p) => {
    const m = p.priceBy
    if (!m) return p.price
    if (hasEvent && m['project:' + projectId] != null) return m['project:' + projectId]
    if (branchId && m['branch:' + branchId] != null) return m['branch:' + branchId]
    if (hasEvent && m.events != null) return m.events
    if (!hasEvent && m.shops != null) return m.shops
    return p.price
  }

  /**
   * 組合優惠的內容物清單（第十七輪回報第 5 項）
   * ------------------------------------------------------------
   * 客人自助點餐頁只看得到品名／售價／選項（見檔案開頭的說明），
   * 所以這裡只把組合內含的「單品名稱＋數量」轉出去，不會洩漏成本、
   * 也不會把整個 comboItems 原始結構（含 productId）送出去。
   */
  const comboContents = (p) => (p.comboItems ?? [])
    .map(ci => {
      const item = (c.products ?? []).find(x => x.id === ci.productId)
      return item ? { name: item.name, qty: ci.qty } : null
    })
    .filter(Boolean)

  /**
   * 套餐拆成一杯一杯的完整資料（第十九批第 3 項）
   * ------------------------------------------------------------
   * comboContents（上面）只給名稱＋數量，是給商品卡「內含什麼」那行純文字顯示用；
   * 這裡的 comboCups 給每一杯完整的商品資料（id、售價、選項群組、預設選項），
   * 讓客人自助點餐頁能像 POS 的「套餐點餐面板」一樣，每一杯各自選規格與加購——
   * 不然客人自助下單永遠只能整份套餐用同一組選項，跟現場點餐體驗不一致。
   * 這裡故意不套 active／availableHere 篩選：套餐裡的單品即使自己沒有單獨上架
   * 販售，裝在套餐裡客人一樣要能選規格（跟 POS 端 ComboOrderSheet 的行為一致）。
   */
  const comboCups = (p) => {
    const out = []
    for (const ci of p.comboItems ?? []) {
      const item = (c.products ?? []).find(x => x.id === ci.productId)
      if (!item) continue
      for (let i = 0; i < ci.qty; i++) {
        out.push({
          productId: item.id, name: item.name, price: priceHere(item),
          emoji: item.emoji || '', imageUrl: item.imageUrl || '',
          optionGroupIds: item.optionGroupIds ?? [], defaultChoices: item.defaultChoices ?? {},
        })
      }
    }
    return out
  }

  const products = (c.products ?? [])
    .filter(p => p.active && availableHere(p.avail))
    .map(p => ({
      id: p.id, name: p.name, category: p.category,
      price: priceHere(p), originalPrice: p.originalPrice || 0,
      emoji: p.emoji, imageUrl: p.imageUrl,
      soldOut: Boolean(p.soldOut), isCombo: Boolean(p.isCombo),
      comboItems: p.isCombo ? comboContents(p) : [],
      comboCups: p.isCombo ? comboCups(p) : [],
      optionGroupIds: p.optionGroupIds ?? [],
      defaultChoices: p.defaultChoices ?? {},
      badge: p.selfBadge || '',
      selfSort: typeof p.selfSort === 'number' ? p.selfSort : undefined,
      description: p.description || '',
    }))

  /**
   * 第十三輪回報第 11 項修正：這裡原本寫 `g.multi`，
   * 但後台「選項與加購」存的欄位其實叫 `multiple` —— 兩個名字對不起來，
   * 導致不管後台有沒有打開「可複選」，客人自助下單頁一律當成單選。
   * 現場一直以為加購能複選，其實從來沒生效過。
   */
  const groups = (c.optionGroups ?? []).map(g => ({
    id: g.id, name: g.name, required: g.required, multi: g.multiple,
    choices: (g.choices ?? []).map(x => ({ id: x.id, name: x.name, priceDelta: x.priceDelta })),
  }))

  const proj = (c.projects ?? []).find(p => p.id === projectId)
  const br = (c.branches ?? []).find(b => b.id === branchId)
  const theme = c.settings?.selfOrderTheme ?? {}

  /**
   * 結帳方式（第十六輪回報第 3、4 項；第十七輪回報第 1 項）
   * ------------------------------------------------------------
   * 後台可以自由新增、刪除任意數量的結帳選項，不再限定 linepay／counter／voucher
   * 三種固定 key。客人頁面只需要知道 id／文字／要不要顯示／是不是線上直接扣款，
   * 「算報表哪一類」「要不要提醒櫃檯」這些是 POS 接單時才用得到的，不送出去。
   * 沒設定過（舊客戶）就照舊給三顆內建的，行為完全不變。
   */
  const DEFAULT_PAY_METHODS = [
    { id: 'linepay', label: 'LINE Pay', sub: '線上付掉', enabled: true, online: true },
    { id: 'counter', label: '現金', sub: '到櫃檯付', enabled: true, online: false },
    { id: 'voucher', label: '折價券', sub: '櫃檯核對', enabled: true, online: false },
  ]
  const configuredPayMethods = Array.isArray(c.settings?.selfOrderPayMethods) && c.settings.selfOrderPayMethods.length
    ? c.settings.selfOrderPayMethods.map((m, i) => ({
        id: m.id || m.key || ('m' + i),
        label: m.label || '結帳',
        sub: m.sub || '',
        enabled: m.enabled !== false,
        online: Boolean(m.online),
      }))
    : DEFAULT_PAY_METHODS

  /**
   * 加點促成提示（第十七輪回報第 4 項；第八批第 1 項擴充成也能推薦加購選項）
   * ------------------------------------------------------------
   * suggestType 'product'：只把「已啟用、觸發商品跟推薦商品都還在這個攤位
   * 賣得到、推薦商品沒賣完」的規則送出去。
   * suggestType 'choice'：推薦的是觸發商品本身「加購」選項群組裡的一個配料
   * （例如加珍珠），所以要另外檢查那個群組確實有綁在觸發商品上、選項也還存在——
   * 不然客人會看到一個點了也套不上去的提示。
   * 不管哪一種，後台刪了商品／群組／選項、或商品在這一場沒上架、賣完，
   * 提示就自動不會再跳出來，不用另外去清規則。
   */
  const sellable = new Set(products.filter(p => !p.soldOut).map(p => p.id))
  const groupById = new Map((c.optionGroups ?? []).map(g => [g.id, g]))
  const configuredUpsellRules = (c.settings?.upsellRules ?? [])
    .filter(r => r.enabled !== false && sellable.has(r.triggerProductId))
    .filter(r => {
      if (r.suggestType === 'choice') {
        const trigger = (c.products ?? []).find(p => p.id === r.triggerProductId)
        if (!trigger || !(trigger.optionGroupIds ?? []).includes(r.suggestGroupId)) return false
        const g = groupById.get(r.suggestGroupId)
        return Boolean(g && (g.choices ?? []).some(ch => ch.id === r.suggestChoiceId))
      }
      // 預設／'product'：不能推薦自己，商品也要還賣得到
      return r.triggerProductId !== r.suggestProductId && sellable.has(r.suggestProductId)
    })
    .map(r => ({
      id: r.id, triggerProductId: r.triggerProductId,
      suggestType: r.suggestType === 'choice' ? 'choice' : 'product',
      suggestProductId: r.suggestProductId, suggestGroupId: r.suggestGroupId, suggestChoiceId: r.suggestChoiceId,
      message: r.message || '',
    }))

  return {
    brandName: c.settings?.brandName ?? '',
    spotName: proj?.name || br?.name || '',
    subtitle: c.settings?.selfOrderSubtitle || '',
    products, optionGroups: groups,
    pay: pay.publicConfig(DATA_DIR),
    payMethods: configuredPayMethods,
    upsellRules: configuredUpsellRules,
    theme: {
      accent: theme.accent || '',
      bg: theme.bg || '',
      cardBg: theme.cardBg || '',
      logo: theme.logo || '',
      logoSize: theme.logoSize || 0,
      badgeFontSize: theme.badgeFontSize || 0,
      nameColor: theme.nameColor || '',
      nameSize: theme.nameSize || 0,
      descColor: theme.descColor || '',
      descSize: theme.descSize || 0,
      priceColor: theme.priceColor || '',
      priceSize: theme.priceSize || 0,
      nameWeight: theme.nameWeight || '',
      descWeight: theme.descWeight || '',
      priceWeight: theme.priceWeight || '',
      fontFamily: theme.fontFamily || '',
      historyBtnText: theme.historyBtnText || '',
      historyBtnSize: theme.historyBtnSize || 0,
      comboContentColor: theme.comboContentColor || '',
      comboContentSize: theme.comboContentSize || 0,
    },
    updatedAt: c.updatedAt ?? 0,
  }
}

// ---------------------------------------------------------------- 發號

/**
 * 集中發號：所有裝置都跟中樞要號，所以永遠是連續的三碼流水號，
 * 也不需要號段預配。中樞就是唯一的真相來源。
 */
function nextSerial(bizDate) {
  // key 只有營業日：叫號是「這個攤位、這一天」的唯一號碼，
  // 帶上場次或分店會讓切換時號碼從 001 重來，現場會叫到兩位客人。
  const key = String(bizDate)
  const n = (serials[key] || 0) + 1
  if (n > 999) throw new Error('今日流水號已達 999，請重置或換日')
  serials[key] = n
  writeJsonAtomic(FILES.serials, serials)
  return { serial: n, serialText: String(n).padStart(3, '0') }
}

// ---------------------------------------------------------------- 列印中繼

function sendToPrinter(host, port, buf, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let settled = false
    const done = (ok, message) => {
      if (settled) return
      settled = true
      try { sock.destroy() } catch {}
      resolve({ ok, message })
    }
    const sock = new net.Socket()
    sock.setTimeout(timeoutMs)
    sock.on('timeout', () => done(false, `連線逾時 ${timeoutMs}ms — 請確認印表機與中樞在同一個熱點`))
    sock.on('error', (e) => done(false, `連線失敗：${e.message}`))
    sock.connect(port, host, () => {
      sock.setNoDelay(true)
      sock.write(buf, () => {
        // 給印表機緩衝時間，避免尾端資料被截斷
        setTimeout(() => done(true, null), 300)
      })
    })
  })
}

// ---------------------------------------------------------------- 備份的資料來源

function backupCtx() {
  return {
    dataDir: DATA_DIR,
    readOrders,
    readConfig: () => config,
    projectName: (projectId, posConfig) => {
      const proj = (posConfig?.projects ?? []).find(p => p.id === projectId)
      return proj?.name || projectId || 'default'
    },
    /**
     * 雲端資料夾的分層資訊（第十一輪回報第 1 項改版）。
     * ------------------------------------------------------------
     * 結構：/品牌POS/{店面,場次}/<店面或場次名稱>/<年度>/<月份>/<營業日>/
     *
     * 舊版是 /品牌POS/<分店>/<資料夾分類>/<年度>/<場次>/<營業日>/ ——
     * 分店永遠在第一層，場次資料夾散在分店底下，年度又插在場次前面，
     * 翻起來要先決定「這是哪家分店」才找得到場次，而客戶其實是先想「今天是店面還是場次」。
     * 改成「店面」「場次」兩個頂層資料夾先分開，底下才是各自的名稱 → 年 → 月 → 當天，
     * 找某個月的某一天，一路點資料夾就到了，不用先猜是哪家分店。
     */
    scopeOf: (projectId, posConfig, bizDate) => {
      const year = (bizDate || '').slice(0, 4) || String(new Date().getFullYear())
      const month = (bizDate || '').slice(5, 7) || String(new Date().getMonth() + 1).padStart(2, '0')
      if (projectId === 'all') {
        return { kind: '店面', name: '全部攤位（品牌總結）', year, month }
      }
      if (String(projectId || '').startsWith('branch:')) {
        const id = String(projectId).slice(7)
        const b = (posConfig?.branches ?? []).find(x => x.id === id)
        return { kind: '店面', name: b?.name || id, year, month }
      }
      if (!projectId || projectId === 'default') {
        return { kind: '店面', name: '店面', year, month }
      }
      const proj = (posConfig?.projects ?? []).find(p => p.id === projectId)
      return { kind: '場次', name: proj?.name || projectId, year, month }
    },
    /**
     * 零用金是「一個攤位一天一筆」。
     * 分店與店面的零用金都存在 projectId='default' 那一筆底下（現場只有一個錢箱），
     * 品牌總結則把當天全部的零用金加起來。
     */
    readCashFloat: (projectId, bizDate, posConfig) => {
      const all = (posConfig?.cashFloats ?? []).filter(f => f.bizDate === bizDate)
      if (projectId === 'all') {
        if (!all.length) return null
        return {
          bizDate,
          entries: all.flatMap(f => f.entries ?? []),
          note: `${all.length} 個攤位的零用金合計`,
        }
      }
      // 分店有自己的零用金（branch:<id>）；找不到才退回 default（舊資料都存在那裡）
      const key = !projectId ? 'default' : projectId
      return all.find(f => (f.projectId || 'default') === key)
        ?? (String(key).startsWith('branch:') ? all.find(f => (f.projectId || 'default') === 'default') : null)
        ?? null
    },
  }
}

// ---------------------------------------------------------------- HTTP

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json',
}

function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, {
    'Content-Type': type,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Cache-Control': 'no-store',
  })
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body))
}

function readBody(req, limit = 8 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let size = 0
    req.on('data', c => {
      size += c.length
      if (size > limit) { reject(new Error('請求過大')); req.destroy(); return }
      chunks.push(c)
    })
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}) }
      catch (e) { reject(new Error('JSON 解析失敗')) }
    })
    req.on('error', reject)
  })
}

function localIps() {
  const out = []
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) {
      if (i.family === 'IPv4' && !i.internal) out.push(i.address)
    }
  }
  return out
}

async function requestHandler(req, res) {
  const url = new URL(req.url, 'http://localhost')
  const p = url.pathname

  if (req.method === 'OPTIONS') return send(res, 204, '')

  try {
    // ---------- API ----------
    if (p === '/api/info') {
      return send(res, 200, { hub: true, version: VERSION, ips: localIps(), port: PORT, httpsPort: httpsServer ? HTTPS_PORT : null, time: Date.now() })
    }

    if (p === '/api/config') {
      if (req.method === 'GET') return send(res, 200, config ?? null)
      if (req.method === 'PUT') {
        config = await readBody(req)
        writeJsonAtomic(FILES.config, config)
        return send(res, 200, { ok: true })
      }
    }

    if (p === '/api/serial' && req.method === 'POST') {
      const { bizDate } = await readBody(req)
      if (!bizDate) return send(res, 400, { error: '缺少 bizDate' })
      return send(res, 200, nextSerial(bizDate))
    }

    if (p === '/api/serial/reset' && req.method === 'POST') {
      const { bizDate } = await readBody(req)
      delete serials[String(bizDate)]
      // 順手清掉舊版帶場次的 key，不然升級後會有兩套計數器打架
      for (const k of Object.keys(serials)) if (k.endsWith(`|${bizDate}`)) delete serials[k]
      writeJsonAtomic(FILES.serials, serials)
      return send(res, 200, { ok: true })
    }

    if (p === '/api/orders') {
      if (req.method === 'GET') {
        const from = url.searchParams.get('from')
        const to = url.searchParams.get('to')
        let list = readOrders()
        if (from) list = list.filter(o => o.bizDate >= from)
        if (to) list = list.filter(o => o.bizDate <= to)
        return send(res, 200, list)
      }
      if (req.method === 'POST') {
        const order = await readBody(req)
        if (!order?.id) return send(res, 400, { error: '缺少訂單 id' })
        order.synced = true
        appendOrder(order)
        return send(res, 200, { ok: true, id: order.id })
      }
    }

    if (p.startsWith('/api/orders/') && req.method === 'PATCH') {
      const id = decodeURIComponent(p.slice('/api/orders/'.length))
      const patch = await readBody(req)
      const cur = readOrders().find(o => o.id === id)
      if (!cur) return send(res, 404, { error: '找不到訂單' })
      appendOrder({ ...cur, ...patch, id })   // jsonl 後寫的覆蓋前面的
      return send(res, 200, { ok: true })
    }

    // ---------------- 金流（LINE Pay）----------------
    // 金鑰只存在中樞。這幾個 API 一律只回「有沒有設定」，不回原文。
    if (p === '/api/pay/config') {
      if (req.method === 'GET') return send(res, 200, pay.publicConfig(DATA_DIR))
      if (req.method === 'PUT') {
        const patch = await readBody(req)
        // 前端把遮蔽字串寫回來時要忽略，不然「已設定」會變成真的密鑰
        for (const k of ['channelSecret', 'channelId']) {
          const v = String(patch[k] ?? '')
          if (!v || v.includes('•') || v === '已設定') delete patch[k]
        }
        return send(res, 200, { ok: true, config: pay.saveConfig(DATA_DIR, patch) })
      }
    }

    if (p === '/api/pay/request' && req.method === 'POST') {
      const body = await readBody(req)
      const origin = req.headers.origin || `http://${req.headers.host}`
      const r = await pay.request(DATA_DIR, {
        id: body.id,
        amount: Number(body.amount),
        productName: body.productName,
        packages: body.packages,
        confirmUrl: `${origin}/api/pay/confirm`,
        cancelUrl: `${origin}/self?pay=cancel`,
      })
      log(r.ok ? `LINE Pay 請款建立：${r.intent.id} ${r.intent.amount} 元` : `LINE Pay 請款失敗：${r.message}`)
      return send(res, 200, r)
    }

    // 客人付完款會被導回這裡（帶 transactionId 與 orderId）
    if (p === '/api/pay/confirm') {
      const id = url.searchParams.get('orderId') || ''
      const txn = url.searchParams.get('transactionId') || ''
      const r = await pay.confirm(DATA_DIR, { id, transactionId: txn })
      log(r.ok ? `LINE Pay 付款完成：${id}` : `LINE Pay 確認失敗：${r.message}`)
      res.writeHead(302, { Location: `/self?pay=${r.ok ? 'ok' : 'fail'}&id=${encodeURIComponent(id)}` })
      return res.end()
    }

    if (p === '/api/pay/status') {
      const id = url.searchParams.get('id') || ''
      return send(res, 200, pay.getIntent(DATA_DIR, id) ?? { status: 'unknown' })
    }

    // ---------------- 電子發票（可串任何平台）----------------
    if (p === '/api/invoice/config') {
      if (req.method === 'GET') return send(res, 200, invoice.publicConfig(DATA_DIR))
      if (req.method === 'PUT') {
        const patch = await readBody(req)
        for (const k of ['hashKey', 'hashIv']) {
          const v = String(patch[k] ?? '')
          if (!v || v === '已設定' || v.includes('•')) delete patch[k]
        }
        return send(res, 200, { ok: true, config: invoice.saveConfig(DATA_DIR, patch) })
      }
    }

    if (p === '/api/invoice/dryrun' && req.method === 'POST') {
      return send(res, 200, invoice.dryRun(DATA_DIR, await readBody(req)))
    }

    if (p === '/api/invoice/issue' && req.method === 'POST') {
      const r = await invoice.issue(DATA_DIR, await readBody(req))
      log(r.ok ? `電子發票已開立${r.number ? '：' + r.number : ''}` : `電子發票開立失敗：${r.message ?? r.status}`)
      return send(res, 200, r)
    }

    // ---------------- 自助下單 ----------------
    if (p === '/api/self/menu') {
      return send(res, 200, selfMenu({
        branchId: url.searchParams.get('branch'),
        projectId: url.searchParams.get('project'),
      }))
    }

    if (p === '/api/self/orders') {
      if (req.method === 'GET') {
        const spot = url.searchParams.get('spot')
        const status = url.searchParams.get('status')
        const phone = url.searchParams.get('phone')
        let list = listRead(FILES.selfOrders)
        if (spot) list = list.filter(x => x.spotKey === spot)
        if (status) list = list.filter(x => x.status === status)
        /**
         * 依電話查歷史訂單（第十三輪回報第 3、4 項）：
         * 客人忘記號碼、或店家婉拒過某一單要找回來核對，都是靠這個電話號碼查。
         * 這裡故意用「完全相符」而不是「包含」——電話號碼本來就該打完整的，
         * 用包含比對反而可能把不同人但號碼片段剛好重疊的訂單也混進來。
         * 只回最近 30 筆，不用把整個資料庫倒出去。
         */
        if (phone) list = list.filter(x => x.phone === phone).slice(0, 30)
        return send(res, 200, list)
      }
      if (req.method === 'POST') {
        // 收攤一鍵關閉：開關關著的時候，就算客人的頁面還沒重新整理、還留著舊菜單，
        // 送單這一步一樣會被擋下來（第十七輪回報第 2 項）
        if (config?.settings?.selfOrderEnabled === false) {
          return send(res, 403, { error: '目前暫停自助下單，請直接到櫃檯點餐' })
        }
        const body = await readBody(req)
        if (!body?.lines?.length) return send(res, 400, { error: '沒有品項' })
        const phone = String(body.phone ?? '').trim()
        if (!phone) return send(res, 400, { error: '請填手機號碼' })
        const item = {
          id: 'self_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
          spotKey: body.spotKey || 'default',
          branchId: body.branchId ?? null,
          projectId: body.projectId ?? null,
          lines: body.lines,
          total: Number(body.total) || 0,
          note: String(body.note ?? '').slice(0, 200),
          contact: String(body.contact ?? '').slice(0, 60),
          phone: phone.slice(0, 20),
          /**
           * 第十七輪回報第 1 項起，結帳方式不再限定 linepay／counter／voucher
           * 三種固定值——後台可以自由新增任意選項，這裡只要是合法字串就收，
           * 沒填或亂填才退回 'counter'（櫃檯付款，最安全的預設）。
           */
          payMethod: String(body.payMethod ?? '').trim().slice(0, 40) || 'counter',
          payMethodLabel: String(body.payMethodLabel ?? '').trim().slice(0, 40),
          payIntentId: body.payIntentId ?? '',
          // 客人自己選的希望取餐時間（選填，第十七輪回報第 6 項）——讓客人可以付完款先離開，晚點再回來拿
          pickupAt: typeof body.pickupAt === 'number' ? body.pickupAt : null,
          status: 'pending',
          createdAt: Date.now(),
        }
        listUpsert(FILES.selfOrders, item)
        log(`自助下單：${item.id}　${item.lines.length} 項　${item.total} 元`)
        return send(res, 200, { ok: true, order: item })
      }
    }

    // 客人的手機用這一支問「我的單被收了沒、幾號」
    if (p.startsWith('/api/self/orders/') && req.method === 'GET') {
      const id = decodeURIComponent(p.slice('/api/self/orders/'.length))
      const cur = listRead(FILES.selfOrders).find(x => x.id === id)
      if (!cur) return send(res, 404, { error: '找不到這筆自助訂單' })
      // 只回客人該知道的：狀態與號碼。別攤的資料、金鑰什麼的都不會在這裡
      return send(res, 200, {
        id: cur.id, status: cur.status, serialText: cur.serialText ?? '',
        total: cur.total, payMethod: cur.payMethod, createdAt: cur.createdAt,
        rejectReason: cur.rejectReason ?? '',
      })
    }

    if (p.startsWith('/api/self/orders/') && req.method === 'PATCH') {
      const id = decodeURIComponent(p.slice('/api/self/orders/'.length))
      const patch = await readBody(req)
      const cur = listRead(FILES.selfOrders).find(x => x.id === id)
      if (!cur) return send(res, 404, { error: '找不到這筆自助訂單' })
      return send(res, 200, { ok: true, order: listUpsert(FILES.selfOrders, { ...cur, ...patch, id }) })
    }

    // ---------------- 遠端補印請求（雙向確認）----------------
    /**
     * 為什麼要「請求」而不是直接印：
     * 標籤機在別攤的桌上。這裡按一下就吐紙，對方會不知道那是什麼、
     * 甚至在忙的時候被打斷。所以一律變成請求 —— 那一攤按「同意」才會印，
     * 而且結果會回報給發起的人（雙向）。過期未處理自動作廢，不會半夜忽然印出來。
     */
    if (p === '/api/printreq') {
      if (req.method === 'GET') {
        const spot = url.searchParams.get('spot')
        const now = Date.now()
        let list = listRead(FILES.printReqs).map(x =>
          (x.status === 'pending' && x.expiresAt && x.expiresAt < now ? { ...x, status: 'expired' } : x))
        if (spot) list = list.filter(x => x.scopeKey === spot || x.fromSpot === spot)
        return send(res, 200, list)
      }
      if (req.method === 'POST') {
        const b = await readBody(req)
        if (!b?.orderId) return send(res, 400, { error: '缺少訂單' })
        const item = {
          id: 'pr_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
          scopeKey: b.scopeKey || 'default',
          fromSpot: b.fromSpot || '',
          fromName: String(b.fromName ?? '').slice(0, 40),
          fromDevice: String(b.fromDevice ?? '').slice(0, 20),
          orderId: b.orderId,
          serialText: b.serialText ?? '',
          labelIds: b.labelIds ?? [],
          reason: String(b.reason ?? '').slice(0, 120),
          status: 'pending',
          createdAt: Date.now(),
          // 10 分鐘沒人處理就過期：現場的事十分鐘後通常已經沒有意義了
          expiresAt: Date.now() + 10 * 60 * 1000,
        }
        listUpsert(FILES.printReqs, item)
        log(`補印請求：${item.serialText || item.orderId} → ${item.scopeKey}`)
        return send(res, 200, { ok: true, request: item })
      }
    }

    if (p.startsWith('/api/printreq/') && req.method === 'PATCH') {
      const id = decodeURIComponent(p.slice('/api/printreq/'.length))
      const patch = await readBody(req)
      const cur = listRead(FILES.printReqs).find(x => x.id === id)
      if (!cur) return send(res, 404, { error: '找不到這筆請求' })
      const next = listUpsert(FILES.printReqs, {
        ...cur, ...patch, id,
        decidedAt: patch.status && patch.status !== 'pending' ? Date.now() : cur.decidedAt,
      })
      log(`補印請求 ${id} → ${next.status}`)
      return send(res, 200, { ok: true, request: next })
    }

    // ---------- 備份 ----------
    if (p === '/api/backup/status') {
      return send(res, 200, backup.status(DATA_DIR))
    }

    if (p === '/api/backup/config' && req.method === 'PUT') {
      const patch = await readBody(req)
      // 遮蔽過的字串代表「不要動原本的憑證」，避免前端把「已設定」寫回去
      for (const k of ['clientSecret', 'refreshToken']) {
        const v = String(patch[k] ?? '')
        if (!v || v.includes('…') || v === '已設定' || v.startsWith('已授權')) delete patch[k]
      }
      backup.saveConfig(DATA_DIR, patch)
      return send(res, 200, { ok: true, config: backup.publicConfig(DATA_DIR) })
    }

    if (p === '/api/backup/test' && req.method === 'POST') {
      const cfg = backup.loadConfig(DATA_DIR)
      if (!cfg.refreshToken) return send(res, 200, { ok: false, message: '尚未完成 Google 雲端授權' })
      try {
        const token = await gdrive.accessToken(cfg)
        const info = await gdrive.about(token)
        await gdrive.ensureFolderPath(token, [cfg.rootFolder])
        backup.saveConfig(DATA_DIR, { account: info.email })
        return send(res, 200, { ok: true, ...info })
      } catch (e) {
        return send(res, 200, { ok: false, message: e.message })
      }
    }

    // ---------- Google 雲端授權（必須在「中樞這台機器」的瀏覽器操作） ----------
    if (p === '/api/gdrive/auth') {
      const cfg = backup.loadConfig(DATA_DIR)
      if (!cfg.clientId || !cfg.clientSecret) {
        return send(res, 400, '請先在 POS 的設定頁填入 Google 用戶端 ID 與密鑰', 'text/plain; charset=utf-8')
      }
      const redirect = `http://localhost:${PORT}/api/gdrive/callback`
      res.writeHead(302, { Location: gdrive.authUrl(cfg.clientId, redirect) })
      return res.end()
    }

    if (p === '/api/gdrive/callback') {
      const code = url.searchParams.get('code')
      const err = url.searchParams.get('error')
      const page = (title, body) =>
        `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">` +
        `<body style="font-family:system-ui,sans-serif;background:#0b1120;color:#e2e8f0;padding:32px;line-height:1.8">` +
        `<h2 style="color:#34d399">${title}</h2>${body}</body>`
      if (err) return send(res, 200, page('❌ 授權被取消', `<p>Google 回覆：${err}</p><p>回到 POS 設定頁再試一次。</p>`), 'text/html; charset=utf-8')
      if (!code) return send(res, 400, page('❌ 沒有收到授權碼', '<p>請從 POS 設定頁重新開始。</p>'), 'text/html; charset=utf-8')
      try {
        const cfg = backup.loadConfig(DATA_DIR)
        const redirect = `http://localhost:${PORT}/api/gdrive/callback`
        const r = await gdrive.exchangeCode({
          clientId: cfg.clientId, clientSecret: cfg.clientSecret, code, redirectUri: redirect,
        })
        let email = ''
        try { email = (await gdrive.about(r.access_token)).email } catch { /* 拿不到就算了 */ }
        backup.saveConfig(DATA_DIR, { refreshToken: r.refresh_token, enabled: true, account: email })
        log(`Google 雲端授權完成${email ? '：' + email : ''}`)
        return send(res, 200, page('✅ Google 雲端授權完成',
          `<p>帳號：<b>${email || '(已連結)'}</b></p><p>可以關掉這個分頁，回到 POS 的設定頁按「測試連線」確認。</p>`),
          'text/html; charset=utf-8')
      } catch (e) {
        return send(res, 200, page('❌ 授權失敗', `<p>${e.message}</p>`), 'text/html; charset=utf-8')
      }
    }

    if (p === '/api/backup/run' && req.method === 'POST') {
      const { projectId, bizDate } = await readBody(req)
      if (!bizDate) return send(res, 400, { ok: false, message: '缺少營業日' })
      const run = await backup.runBackup(backupCtx(), { projectId, bizDate })
      let pruned = null
      if (run.ok) pruned = backup.pruneOrders(backupCtx(), { ordersFile: FILES.orders })
      log(run.ok ? `備份成功 ${run.projectName}/${run.bizDate}（${run.orders} 筆）` : `備份失敗：${run.error}`)
      return send(res, 200, { ...run, pruned })
    }

    if (p === '/api/backup/retry' && req.method === 'POST') {
      const results = await backup.retryPending(backupCtx())
      return send(res, 200, { results })
    }

    // ---------------- 月結自動上傳（第十一輪回報第 1 項）----------------
    if (p === '/api/backup/monthly-status') {
      return send(res, 200, backup.monthlyStatus(DATA_DIR))
    }
    // 手動觸發（設定頁「立即結算上個月」按鈕用，也方便測試）。
    // 手動觸發一律無視日期窗口與「這個月結過了沒」的檢查——使用者主動按了就是要它現在跑。
    // body 可傳 { yearMonth: 'YYYY-MM' } 指定要結哪個月；不傳就是「上個月」。
    if (p === '/api/backup/monthly-run' && req.method === 'POST') {
      const { yearMonth } = await readBody(req).catch(() => ({}))
      const result = await backup.checkAndRunMonthlyBackups(backupCtx(), { force: true, forceMonth: yearMonth || null })
      const okCount = (result.results ?? []).filter(r => r.ok && !r.skippedEmpty).length
      log(result.skipped ? `月結上傳略過：${result.skipped}` : `月結上傳（${result.yearMonth}）完成 ${okCount} 攤`)
      return send(res, 200, result)
    }

    // ---------------- 檢查更新 ----------------
    // 只要更新中樞這一台，所有 iPad 下次重新整理就是新版了。
    if (p === '/api/update/status') {
      return send(res, 200, update.status(DATA_DIR, VERSION))
    }
    if (p === '/api/update/config' && req.method === 'PUT') {
      const body = await readBody(req)
      const cfg = update.saveConfig(DATA_DIR, {
        manifestUrl: String(body.manifestUrl ?? '').trim(),
        autoCheck: Boolean(body.autoCheck),
        channel: String(body.channel || 'stable'),
      })
      return send(res, 200, { ok: true, config: cfg })
    }
    if (p === '/api/update/check' && req.method === 'POST') {
      const r = await update.check(DATA_DIR, VERSION)
      log(r.hasUpdate ? `有新版可以更新：${r.latest.version}` : '檢查更新：目前已是最新版')
      return send(res, 200, r)
    }
    if (p === '/api/update/install' && req.method === 'POST') {
      try {
        const r = await update.install(DATA_DIR, ROOT, VERSION)
        log(`已更新到 ${r.version}，準備自動重新啟動中樞…`)
        send(res, 200, { ...r, autoRestart: true })
        if (r.ok) scheduleAutoRestart()
        return
      } catch (e) {
        log(`更新失敗：${e.message}`)
        return send(res, 200, { ok: false, error: e.message })
      }
    }
    if (p === '/api/update/rollback' && req.method === 'POST') {
      try {
        const r = update.rollback(DATA_DIR, ROOT)
        log(`已還原到 ${r.version}，準備自動重新啟動中樞…`)
        send(res, 200, { ...r, autoRestart: true })
        if (r.ok) scheduleAutoRestart()
        return
      } catch (e) {
        return send(res, 200, { ok: false, error: e.message })
      }
    }

    if (p === '/api/print' && req.method === 'POST') {
      const { dataBase64, host, port = 9100, timeoutMs = 8000 } = await readBody(req)
      const target = host || process.env.PRINTER
      if (!target) return send(res, 400, { ok: false, message: '未設定印表機 IP' })
      if (!dataBase64) return send(res, 400, { ok: false, message: '沒有列印資料' })
      const buf = Buffer.from(dataBase64, 'base64')
      const r = await sendToPrinter(target, Number(port), buf, Number(timeoutMs))
      log(r.ok ? `列印 ${buf.length} bytes → ${target}:${port} 成功` : `列印失敗：${r.message}`)
      return send(res, 200, r)
    }

    if (p === '/api/printer/ping' && req.method === 'POST') {
      const { host, port = 9100, timeoutMs = 5000 } = await readBody(req)
      const target = host || process.env.PRINTER
      if (!target) return send(res, 400, { ok: false, message: '未設定印表機 IP' })
      // ESC @ 初始化指令，印表機收到不會有動作，純粹測通不通
      const r = await sendToPrinter(target, Number(port), Buffer.from([0x1b, 0x40]), Number(timeoutMs))
      return send(res, 200, r)
    }

    if (p === '/api/discover' && req.method === 'POST') {
      // 掃描本網段有哪些裝置開著 9100 埠 —— 找不到印表機 IP 時用
      const { subnet, port = 9100 } = await readBody(req)
      const base = subnet || (localIps()[0] || '').split('.').slice(0, 3).join('.')
      if (!base) return send(res, 400, { hosts: [] })
      const found = []
      await Promise.all(Array.from({ length: 254 }, (_, i) => new Promise(resolve => {
        const ip = `${base}.${i + 1}`
        const s = new net.Socket()
        s.setTimeout(900)
        const end = () => { try { s.destroy() } catch {} ; resolve() }
        s.on('timeout', end)
        s.on('error', end)
        s.connect(port, ip, () => { found.push(ip); end() })
      })))
      return send(res, 200, { hosts: found.sort() })
    }

    // ---------- 靜態檔 ----------
    let file = p === '/' ? '/index.html' : p
    const abs = path.join(ROOT, 'www', path.normalize(file).replace(/^(\.\.[/\\])+/, ''))
    if (fs.existsSync(abs) && fs.statSync(abs).isFile()) {
      const ext = path.extname(abs).toLowerCase()
      return send(res, 200, fs.readFileSync(abs), MIME[ext] || 'application/octet-stream')
    }
    // SPA 後備
    const index = path.join(ROOT, 'www', 'index.html')
    if (fs.existsSync(index)) return send(res, 200, fs.readFileSync(index), MIME['.html'])

    return send(res, 404, { error: '找不到頁面。請確認 www/index.html 存在' })
  } catch (e) {
    return send(res, 500, { error: e.message })
  }
}

const server = http.createServer(requestHandler)

function log(msg) {
  const t = new Date().toLocaleTimeString('zh-TW', { hour12: false })
  console.log(`[${t}] ${msg}`)
}

/**
 * 更新／還原成功後，等回應送出去再自動關閉行程（結束碼 75）。
 * start.sh 看到 75 這個結束碼會自動在 3 秒後重開，
 * 這樣以後每次更新都不用人工重新啟動中樞。
 */
function scheduleAutoRestart() {
  setTimeout(() => {
    log('自動重新啟動中樞…')
    process.exit(75)
  }, 1500)
}

/**
 * HTTPS：讓網頁本身能離線打開（Service Worker）的必要條件
 * ------------------------------------------------------------
 * 瀏覽器的安全規範規定 Service Worker 只能在「安全連線」下註冊——
 * https:// 或是 localhost／127.0.0.1 這種特例才算，中樞平常用的
 * 私有 IP（例如 192.168.43.1）走一般 http 並不算安全連線，
 * 所以離線打開網頁這個功能一定要走 https 才會生效。
 * 憑證是自簽的（見 certgen.js 開頭說明），第一次連線瀏覽器會跳出
 * 「不安全連線」的警告，按一次「繼續前往」之後同一台裝置就不會再跳。
 * 憑證產生失敗（例如環境不支援）不應該讓整個中樞開不起來，
 * 所以這裡包一層 try/catch，失敗的話中樞照樣用 http 正常運作，
 * 只是離線開網頁這個功能會不可用。
 */
let httpsServer = null
try {
  const { certPem, keyPem } = certgen.ensureCert(DATA_DIR, localIps())
  httpsServer = https.createServer({ key: keyPem, cert: certPem }, requestHandler)
} catch (e) {
  log(`HTTPS 憑證準備失敗，將只提供 http（離線打開網頁功能會不可用）：${e.message}`)
}

server.listen(PORT, '0.0.0.0', () => {
  const ips = localIps()
  console.log('')
  console.log('  ┌──────────────────────────────────────────────┐')
  console.log('  │        市集 POS  攤位中樞 已啟動             │')
  console.log('  └──────────────────────────────────────────────┘')
  console.log('')
  if (httpsServer) {
    console.log('  在 iPad 的 Safari 打開下面任一個網址（建議用這個，離線也能打開網頁）：')
    for (const ip of ips) console.log(`      https://${ip}:${HTTPS_PORT}`)
    console.log('  第一次連線瀏覽器會顯示「不安全連線」警告，這是正常的（因為是自己簽的憑證，')
    console.log('  不是跟公司買的），點「進階」→「繼續前往」即可，同一台裝置以後不會再跳。')
    console.log('')
    console.log('  也可以繼續用原本的網址（不需要離線打開網頁時可以用這個）：')
    for (const ip of ips) console.log(`      http://${ip}:${PORT}`)
  } else {
    console.log('  在 iPad 的 Safari 打開下面任一個網址：')
    for (const ip of ips) console.log(`      http://${ip}:${PORT}`)
  }
  if (!ips.length) console.log('      (找不到網路介面，請先開啟熱點)')
  console.log('')
  console.log(`  這台機器自己用：  http://127.0.0.1:${PORT}`)
  console.log(`  資料存放位置：    ${DATA_DIR}`)
  console.log('')
  console.log('  按 Ctrl+C 可停止。關掉這個視窗中樞就會停，出單會停擺。')
  console.log('')
})

if (httpsServer) {
  httpsServer.listen(HTTPS_PORT, '0.0.0.0', () => {
    log(`HTTPS 服務已啟動（連接埠 ${HTTPS_PORT}）`)
  })
  httpsServer.on('error', (e) => log(`HTTPS 服務啟動失敗（已忽略，http 照常運作）：${e.message}`))
}

process.on('uncaughtException', (e) => log(`未預期錯誤（已忽略，服務繼續）：${e.message}`))

// 待上傳的備份每 10 分鐘自動重試一次 —— 市集現場沒訊號時排隊，回家有 Wi-Fi 就自己補傳
setInterval(async () => {
  try {
    const st = backup.status(DATA_DIR)
    if (!st.config.hasAuth || !st.pending.length) return
    log(`偵測到 ${st.pending.length} 筆待上傳備份，嘗試補傳…`)
    const results = await backup.retryPending(backupCtx())
    const okCount = results.filter(r => r.ok).length
    if (okCount) log(`補傳成功 ${okCount} 筆`)
  } catch (e) {
    log(`備份補傳失敗：${e.message}`)
  }
}, 10 * 60 * 1000)

/**
 * 月結自動上傳的檢查（第十一輪回報第 1 項）。
 * ------------------------------------------------------------
 * 開機時先檢查一次（萬一剛好在月初那幾天中樞沒開機，開機時補上），
 * 之後每小時再檢查一次。checkAndRunMonthlyBackups 自己會判斷「現在算不算月初」
 * 跟「上個月結過了沒」，所以這裡不用自己算日期，只要固定頻率呼叫就好。
 */
async function checkMonthlyBackups() {
  try {
    const result = await backup.checkAndRunMonthlyBackups(backupCtx())
    if (result.skipped) return
    const okCount = (result.results ?? []).filter(r => r.ok && !r.skippedEmpty).length
    const failCount = (result.results ?? []).filter(r => !r.ok).length
    log(`月結自動上傳（${result.yearMonth}）：成功 ${okCount} 攤${failCount ? `，失敗 ${failCount} 攤（下次會重跑整個月）` : ''}`)
  } catch (e) {
    log(`月結自動上傳失敗：${e.message}`)
  }
}
setTimeout(checkMonthlyBackups, 15 * 1000)   // 開機先等中樞穩定一下再檢查，不搶開機那幾秒的資源
setInterval(checkMonthlyBackups, 60 * 60 * 1000)
