-- ============================================================
-- 市集 POS × Supabase 建表 SQL
-- ============================================================
-- 用法：Supabase 專案 → 左側 SQL Editor → New query → 整段貼上 → Run
-- 跑完之後到 Authentication → Users 建立你自己的帳號（Email + 密碼），
-- 再回 POS 的「設定 → Supabase 雲端資料庫」填網址、anon key 並登入。
--
-- 設計重點
-- ------------------------------------------------------------
-- 1. 訂單明細用 jsonb 存整包快照，不拆成 order_items 表。
--    理由：歷史訂單的價格與成本必須「凍結」——
--    明天調價，昨天的毛利不能跟著變。
-- 2. 金額一律整數（元），不用 float。0.1 + 0.2 !== 0.3。
-- 3. branch_id 與 project_id 是兩個獨立欄位，不是同一個維度。
--    中山店的人去參加咖啡節 —— 合併成一欄就永遠算不出
--    「中山店這個月總共賺多少（含市集）」。
-- 4. RLS 全開，而且 anon 什麼都不能做。POS 一定要登入才讀寫得到。
-- ============================================================

-- ---------- 分店 ----------
create table if not exists public.branches (
  id          text primary key,
  name        text not null,
  address     text default '',
  note        text default '',
  active      boolean default true,
  sort        int default 0,
  created_at  timestamptz default now()
);

-- ---------- 場次 ----------
create table if not exists public.projects (
  id          text primary key,
  branch_id   text references public.branches(id) on delete set null,
  name        text not null,
  folder      text default '',          -- 資料夾分類：北部／中部…
  start_date  date,
  end_date    date,
  location    text default '',
  booth_fee   int default 0,
  active      boolean default true,
  created_at  timestamptz default now()
);

-- ---------- 訂單 ----------
create table if not exists public.orders (
  id              text primary key,     -- 裝置端產生：場次-裝置-營業日-序號
  branch_id       text references public.branches(id) on delete set null,
  project_id      text references public.projects(id) on delete set null,
  device_code     text,
  biz_date        date not null,
  serial          int,
  serial_text     text,
  created_at      timestamptz not null,

  items           jsonb not null,       -- 品項＋選項＋備註＋單價＋成本的快照
  payments        jsonb not null,       -- 混合付款明細
  customer_tags   jsonb default '{}'::jsonb,

  total_qty       int default 0,
  subtotal        int default 0,
  discount        int default 0,
  adjustment      int default 0,
  total           int default 0,
  cost            int default 0,

  pay_method      text,
  paid_confirmed  boolean default true,
  pickup_at       timestamptz,
  picked_at       timestamptz,
  status          text default 'paid',
  staff           text default '',
  channel         text default 'staff',
  note            text default '',

  synced_at       timestamptz default now()
);

create index if not exists orders_scope   on public.orders (branch_id, biz_date);
create index if not exists orders_project on public.orders (project_id, biz_date);
create index if not exists orders_date    on public.orders (biz_date);

-- ---------- 支出 ----------
create table if not exists public.expenses (
  id           text primary key,
  branch_id    text references public.branches(id) on delete set null,
  project_id   text references public.projects(id) on delete set null,
  date         date not null,
  category     text,
  name         text default '',
  vendor       text default '',
  invoice_no   text default '',
  unit_price   int default 0,
  qty          int default 0,
  amount       int default 0,
  pay_method   text default 'cash',
  pay_account  text default '',
  paid         boolean default false,
  auto_source  text,                    -- 'boothFee' = 由場次自動產生
  staff        text default '',
  note         text default '',
  created_at   timestamptz default now(),
  synced_at    timestamptz default now()
);

create index if not exists expenses_scope on public.expenses (branch_id, date);
create index if not exists expenses_date  on public.expenses (date);

-- ============================================================
-- Row Level Security
-- ============================================================
-- anon key 是公開的（按 F12 就看得到），所以安全性完全靠這一段。
-- 規則：**只有登入過的使用者**才讀得到、寫得進去。
--
-- using      → 管「能不能讀到這一列」
-- with check → 管「能不能寫進這一列」
-- 兩個都要寫。只寫 using 的話，別人塞得進資料，只是自己看不到而已。
-- ============================================================

alter table public.branches enable row level security;
alter table public.projects enable row level security;
alter table public.orders   enable row level security;
alter table public.expenses enable row level security;

do $$
declare t text;
begin
  foreach t in array array['branches','projects','orders','expenses'] loop
    execute format('drop policy if exists "authenticated_all" on public.%I', t);
    execute format($f$
      create policy "authenticated_all" on public.%I
        for all
        to authenticated
        using (true)
        with check (true)
    $f$, t);
  end loop;
end $$;

-- ------------------------------------------------------------
-- 資料表本身的存取權限（跟上面的 RLS policy 是兩件事）
-- ------------------------------------------------------------
-- RLS policy 管的是「這一列准不准讀寫」，但 Postgres 在檢查 RLS 之前，
-- 會先檢查這個角色對這張表本身有沒有基本的 GRANT 權限 —— 兩者都要有，
-- 缺了任何一個都會被擋下來（缺這個會直接看到 42501 permission denied，
-- 而不是「連線正常但沒登入」那種 RLS 擋下來的訊息）。
-- 大多數 Supabase 新專案會自動有這個權限，但如果你遇到
-- 「42501 permission denied for table ...」，代表你的專案沒有 ——
-- 補跑這一段就好，不影響上面已經建好的表跟資料。
grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;

-- ============================================================
-- 未來要賣給其他攤商時（多租戶）
-- ============================================================
-- 現在是「一個攤商 = 一個 Supabase 專案」，所以上面的 policy 夠用。
-- 等到要一個專案服務很多攤商時，照下面改：
--
--   1. 每張表加 tenant_id：
--        alter table public.orders add column tenant_id uuid not null;
--   2. 建立 memberships 表，記錄哪個 user 屬於哪個 tenant
--   3. policy 改成比對 JWT 裡的 tenant_id：
--        using      (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid)
--        with check (tenant_id = (auth.jwt() ->> 'tenant_id')::uuid)
--
-- 上線前一定要驗收：用 A 攤商的 token 硬打 API 要 B 攤商的訂單，
-- 必須回空陣列而不是資料。這件事沒測過就不能收客戶的錢。
-- ============================================================

-- ---------- 常用查詢：品項統計（jsonb 展開一樣很快） ----------
-- select it->>'productName' as 品項,
--        sum((it->>'qty')::int) as 杯數,
--        sum((it->>'unitPrice')::int * (it->>'qty')::int) as 營收
-- from public.orders o, jsonb_array_elements(o.items) it
-- where o.biz_date between '2026-08-01' and '2026-08-31'
--   and o.status <> 'void'
-- group by 1 order by 3 desc;
